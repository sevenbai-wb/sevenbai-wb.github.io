const FWOTA_BASE_URL = 'https://webduinoio.github.io/wafirmata/';
const OTA_BASE_URL = 'https://sevenbai-wb.github.io/WBitBlocklyOTA/';
const INSTALLER_PAGE_URL = 'http://gg.gg/downloadwebbit';
const request = require('request');
const path = require('path');
const fs = require('fs');
const cp = require('child_process');
const appInfo = require('./package.json');
const WebSocketServer = require('websocket').server;
const http = require('http');
// for OTA from old version, there is no express in node_module,
// we have to handle this case
let express = null;
try {
    express = require('express');
} catch (error) {}

const LOG_LEVEL = 1;    // 0: none. 1: important. 2: all.
let fwUrl = FWOTA_BASE_URL;
let portId = null;
let portPaths = [];
let deviceId = '';
let fwVersion = '';
let newFWVersion = '';
let wifiSetting = {
    ssid: '',
    pwd: ''
};
let wsConnection = null;
const APPNAME = appInfo.description;
const VERSION = appInfo.version;
const REMOTE_URL = 'https://webbit.webduino.io/blockly/';
const LOCAL_URL = 'http://localhost:20975/blockly/';
let DEFAULT_URL = REMOTE_URL;   // default to remote url
let titleMsg = '';
let mainwin = null;
let isUSBOff = false;
let toolmenu_usboff;
let manuallyUpdateNotify = false;
let currentLang = 'zh-hant';

// localization
function _(fmt, ...args) {
    return fmt.replace(/((?:[^{}]|(?:\{\{)|(?:\}\}))+)|(?:\{([0-9]+)\})/g, (m, str, index) => {
        if (str) {
            return str.replace(/(?:{{)|(?:}})/g, m => m[0]);
        } else {
            if (index >= args.length) {
                throw new Error('argument index is out of range in format');
            }
            return args[index];
        }
    });
}

function reportToWebPage(info) {
    if (mainwin) {
        let json = JSON.stringify(info);
        mainwin.eval(null,
            `Blockly.detectUSB(${json});`
        );
    }
}

function updateTitle(msg) {
    if (msg) {
        titleMsg = (DEFAULT_URL.indexOf(REMOTE_URL) === 0 ? _('(線上版)') : '') + `${APPNAME} V${VERSION} - ${msg}`;
    }
    if (mainwin) {
        mainwin.eval(null,
            `document.getElementsByTagName("title")[0].innerText = "${titleMsg}";`
        );
    }
}

function serialSend(bitPortId, data) {
    chrome.serial.send(bitPortId, data, sendInfo => {});
    chrome.serial.flush(bitPortId, result => {});
    // wait for board to receive serial data
    let start = Date.now();
    while (Date.now() - start < (data.byteLength/2));
}

function checkNewFirmware() {
    newFWVersion = '';
    let d = new Date();
    let r = '?' + d.getTime();
    // download esptool
    const flasherDir = path.join(__dirname, '/BitFlasher');
    if (!fs.existsSync(flasherDir)) {
        fs.mkdirSync(flasherDir);
        request(OTA_BASE_URL + 'BitFlasher/esptool.bin' + r).on('end', () => {
            fs.renameSync(__dirname + '/BitFlasher/esptool.bin', __dirname + '/BitFlasher/esptool.exe');
        }).pipe(fs.createWriteStream(__dirname + '/BitFlasher/esptool.bin'));
        request(OTA_BASE_URL + 'BitFlasher/boot_app0.bin' + r).pipe(fs.createWriteStream(__dirname + '/BitFlasher/boot_app0.bin'));
        request(OTA_BASE_URL + 'BitFlasher/partitions.bin' + r).pipe(fs.createWriteStream(__dirname + '/BitFlasher/partitions.bin'));
        request(OTA_BASE_URL + 'BitFlasher/bootloader_dio_40m.bin' + r).pipe(fs.createWriteStream(__dirname + '/BitFlasher/bootloader_dio_40m.bin'));
    }
    if (!fs.existsSync(__dirname + '/BitFlasher/esptool.exe')) {
        // downloading esptool, check later...
        setTimeout(checkNewFirmware, 1000);
        return;
    }

    request(fwUrl + 'bit_version.last' + r, (err, res, data) => {
        if (err) return;
        let latestVersion = data.toString().replace(/\r|\n/g,"");
        if (latestVersion.length < 50 && fwVersion != latestVersion) {
            fs.writeFileSync(__dirname + '/BitFlasher/bit_version.last', latestVersion);
            if (fs.existsSync(__dirname + '/BitFlasher/' + latestVersion + '.bin')) {
                fs.copyFileSync(__dirname + '/BitFlasher/' + latestVersion + '.bin', __dirname + '/BitFlasher/bit_default.bin');
            } else {
                try {
                    fs.unlinkSync(__dirname + '/BitFlasher/bit_default.bin');                    
                } catch (error) {}
            }
            newFWVersion = latestVersion;
            updateTitle(_('偵測到新版韌體 {0} (目前版本 {1})，請按 Ctrl-Shift-F 進行更新', newFWVersion, fwVersion));
            let ok = (fwVersion === '?') ? true : mainwin.eval(null,`confirm("${_('偵測到新版韌體，是否立即更新？')}");`);
            if (ok === true) {
                setTimeout(startFlash, 1);
            }
        }
    });
}
function startFlash() {
    if (newFWVersion.length === 0) {
        mainwin.eval(null,`alert("${_('沒有發現新版韌體')}");`);
    } else if (portId != null && deviceId !== '') {
        if (!fs.existsSync(__dirname + '/BitFlasher/bit_default.bin')) {
            updateTitle(_('下載韌體 {0}...', newFWVersion));
            let d = new Date();
            let r = '?' + d.getTime();
            request(fwUrl + 'bit_default.bin' + r).on('end', () => {
                fs.copyFileSync(__dirname + '/BitFlasher/' + newFWVersion + '.bin', __dirname + '/BitFlasher/bit_default.bin');
                setTimeout(startFlash, 1000);
            }).pipe(fs.createWriteStream(__dirname + '/BitFlasher/' + newFWVersion + '.bin'));
            return;
        }
        mainwin.eval(null,`alert("${_('更新時請勿關閉程式或拔除 USB 線')}");`);
        try {
            updateTitle(_('韌體 {0} 下載完成，準備更新...', newFWVersion));
            chrome.serial.disconnect(portId, result => {
                setTimeout(()=>{    // delay 2 sec to wait for disconnection
                    if (LOG_LEVEL >= 1) console.log('Flashing firmware...');
                    let flasher = cp.spawn('esptool.exe', [
                        '-p', portPaths[portId],
                        '-b','921600',
                        'write_flash',
                        '-z',
                        '-fm','dio',
                        '-ff','40m',
                        '-fs','detect',
                        '0x1000','bootloader_dio_40m.bin',
                        '0x8000','partitions.bin',
                        '0xe000','boot_app0.bin',
                        '0x10000','bit_default.bin'], {
                            cwd: './BitFlasher/'
                    });
                    flasher.stdout.on('data', (data) => {
                        let msg = data.toString().replace(/\r?\n|\r/g,"");
                        updateTitle(msg);
                    });
                    flasher.on('close', (code) => {
                        if (LOG_LEVEL >= 1) console.log(`child process exited with code ${code}`);
                        // Reconnect board
                        isUSBOff = false;
                        portId = null;
                        deviceId = '';
                        scanBoard();
                    });
                }, 2000);
            });
        } catch (error) {
            updateTitle(_('新版韌體 {0} 更新失敗', newFWVersion));
            isUSBOff = false;
            portId = null;
            deviceId = '';
            scanBoard();
        }
    } else {
        mainwin.eval(null,`alert("${_('裝置未連線')}");`);
    }
}

function repairFlash() {
    let ok = mainwin.eval(null,`confirm("${_('強制更新韌體可修復韌體相關問題。\\n為避免偵測錯誤，請先移除 Web:Bit 以外的 USB 裝置。\\n請是否繼續？')}");`);
    if (ok !== true) return;

    // Turn off USB and disconnect all connections
    updateTitle(_(`關閉 USB 連線...`));
    isUSBOff = true;
    chrome.serial.getConnections(connections=>{
        connections.forEach(c => {
            chrome.serial.disconnect(c.connectionId, result=>{});
        });
    })

    setTimeout(() => {
        // find COM port
        chrome.serial.getDevices(ports => {
            let comName = '';
            for (let i = 0; i < ports.length; i++) {
                if (ports[i].vendorId === 6790 && ports[i].productId === 29987) {
                    comName = ports[i].path;
                    break;
                }
            }
            if (comName.length === 0) {
                mainwin.eval(null,`alert("${_('偵測不到裝置，請檢查 USB 連線！')}");`);
                // Reconnect board
                isUSBOff = false;
                portId = null;
                deviceId = '';
                scanBoard();
                return;
            }
            portPaths[0] = comName;
            portId = 0;
            deviceId = 'unknown';

            // flash
            fwVersion = '?';
            checkNewFirmware();        
        });
    }, 1000);
}

// Determine open remote or local url
if (express && fs.existsSync('./blockly/index.html')) {
    // Launch local http server
    let app = express();
    app.use(express.static('.'));
    app.listen(20975, function () {
        if (LOG_LEVEL >= 1) console.log('Local Server Started.');
    });
    // Turn to local url
    DEFAULT_URL = LOCAL_URL;
} else {
    manuallyUpdateNotify = true;
}

function showHelp() {
    if (mainwin) {
        mainwin.eval(null,`alert("${_('Ctrl+H: 顯示快捷鍵說明\\n\\nCtrl+Shift+F: 更新韌體\\nCtrl+Shift+R: 強制更新韌體\\nCtrl+Shift+I: 複製 DeviceID 到剪貼簿\\nCtrl+Shift+W: 設定 WiFi\\nCtrl+Shift+U: 切換 USB 連線')}");`);
    }
}
function copyDeviceId() {
    if (mainwin) {
        if (portId != null && deviceId !== '') {
            let clipboard = nw.Clipboard.get();
            clipboard.set(deviceId, 'text');
            mainwin.eval(null,`alert("${_('裝置 ID [{0}] 已複製到剪貼簿', deviceId)}");`);
        } else {
            mainwin.eval(null,`alert("${_('裝置未連線')}");`);
        }    
    }
}
function USBOff(isOff) {
    if (isOff === 'toggle') isOff = !isUSBOff;
    let ok = mainwin.eval(null, isOff ? `confirm("${_('關閉 USB 連線？')}");` : `confirm("${_('開啟 USB 連線？')}");`);
    if (ok === true) {
        isUSBOff = isOff;
        if (isUSBOff) {
            chrome.serial.getConnections(connections=>{
                connections.forEach(c => {
                    chrome.serial.disconnect(c.connectionId, result=>{});
                });
            })
            serialSend(portId, msgRebootDevice);
        }
        portId = null;
        deviceId = '';
        scanBoard();
    }
    toolmenu_usboff.checked = isUSBOff;
}
function setupWiFi() {
    if (mainwin) {
        if (portId != null && deviceId !== '') {
            wifiSetting.ssid = mainwin.eval(null,`prompt("${_('設定[{0}]的連線 SSID:', deviceId)}", "${wifiSetting.ssid}");`);
            if (wifiSetting.ssid.length === 0) return;
            wifiSetting.pwd = mainwin.eval(null,`prompt("${_('設定[{0}]的連線密碼:', deviceId)}", "${wifiSetting.pwd}");`);
            let cmd = [0xf0,0x0e,0x0d]
                      .concat(wifiSetting.ssid.split('').map(c => c.charCodeAt(0)))
                      .concat(0x1f)
                      .concat(wifiSetting.pwd.split('').map(c => c.charCodeAt(0)))
                      .concat(0xf7);
            // console.log(cmd);
            try {
                serialSend(portId, convertArrayToArrayBuffer(cmd));
                USBOff(true);
            } catch (error) {}
        } else {
            mainwin.eval(null,`alert("${_('裝置未連線')}");`);
        }    
    }
}

// Launch Bit Blockly
nw.Window.open(DEFAULT_URL + '?lang=' + currentLang, {
    focus: true,
    // icon: 'icon.png',
    min_width: 800,
    min_height: 600,
    // fullscreen: true
}, function (win) {
    mainwin = win;
    win.maximize();
    let mainmenu;

    /*
    *  Create main menu
    */
    {
        mainmenu = new nw.Menu({ type: 'menubar' });
        // 系統
        let systemmenu = new nw.Menu();
        let systemmenu_browser = new nw.MenuItem({
            label: _('以瀏覽器開啟'),
            click: function() {
                nw.Shell.openExternal(DEFAULT_URL);
            },
        });
        systemmenu.append(systemmenu_browser);
        let systemmenu_exit = new nw.MenuItem({
            label: _('結束'),
            click: function() {
                process.exit();
            },
            // key: 'q',
            // modifiers: 'alt',    
        });
        systemmenu.append(systemmenu_exit);
        mainmenu.append(new nw.MenuItem({
            label: _('系統'),
            submenu: systemmenu
        }));
        // 工具
        let toolmenu = new nw.Menu();
        toolmenu_usboff = new nw.MenuItem({
            label: _('關閉 USB 連線'),
            type: 'checkbox',
            checked: isUSBOff,
            click: function() { USBOff('toggle');},
            // key: 'u',
            // modifiers: 'alt',    
        });
        toolmenu.append(toolmenu_usboff);
        let toolmenu_wifisetting = new nw.MenuItem({
            label: _('設定 WiFi'),
            click: setupWiFi,
            // key: 'w',
            // modifiers: 'alt',    
        });
        toolmenu.append(toolmenu_wifisetting);
        let toolmenu_flash = new nw.MenuItem({
            label: _('更新韌體'),
            click: startFlash,
            // key: 'f',
            // modifiers: 'alt',    
        });
        toolmenu.append(toolmenu_flash);
        let toolmenu_repairFlash = new nw.MenuItem({
            label: _('強制更新韌體'),
            click: repairFlash,
            // key: 'r',
            // modifiers: 'alt',    
        });
        toolmenu.append(toolmenu_repairFlash);
        mainmenu.append(new nw.MenuItem({
            label: _('工具'),
            submenu: toolmenu
        }));
        // 資訊
        let infomenu = new nw.Menu();
        let infomenu_version = new nw.MenuItem({
            label: _('版本：') + VERSION,
        });
        infomenu.append(infomenu_version);
        let infomenu_device = new nw.MenuItem({
            label: _('複製裝置 ID'),
            click: copyDeviceId,
            // key: 'i',
            // modifiers: 'alt',    
        });
        infomenu.append(infomenu_device);
        let infomenu_help = new nw.MenuItem({
            label: _('快捷鍵說明'),
            click: showHelp,
            // key: 'h',
            // modifiers: 'alt',    
        });
        infomenu.append(infomenu_help);
        mainmenu.append(new nw.MenuItem({
            label: _('資訊'),
            submenu: infomenu
        }));
    }

    /*
    *  Global Hotkey settings
    */
    // Show help
    nw.App.registerGlobalHotKey(new nw.Shortcut({
        key : "Ctrl+H",
        active : showHelp,
        failed : function(msg) {
            if (LOG_LEVEL >= 1) console.log(msg);
        }
    }));

    // Show/Hide menu
    nw.App.registerGlobalHotKey(new nw.Shortcut({
        key : "Ctrl+W",
        active : function() {
            win.menu = ((win.menu === mainmenu) ? null : mainmenu);
        },
        failed : function(msg) {
            if (LOG_LEVEL >= 1) console.log(msg);
        }
    }));

    // Flash firmware
    nw.App.registerGlobalHotKey(new nw.Shortcut({
        key : "Ctrl+Shift+F",
        active : startFlash,
        failed : function(msg) {
            if (LOG_LEVEL >= 1) console.log(msg);
        }
    }));

    // Repair Flash firmware
    nw.App.registerGlobalHotKey(new nw.Shortcut({
        key : "Ctrl+Shift+R",
        active : repairFlash,
        failed : function(msg) {
            if (LOG_LEVEL >= 1) console.log(msg);
        }
    }));

    // Copy device id to clipboard
    nw.App.registerGlobalHotKey(new nw.Shortcut({
        key : "Ctrl+Shift+I",
        active : copyDeviceId,
        failed : function(msg) {
            if (LOG_LEVEL >= 1) console.log(msg);
        }
    }));

    // setup WiFi
    nw.App.registerGlobalHotKey(new nw.Shortcut({
        key : "Ctrl+Shift+W",
        active : setupWiFi,
        failed : function(msg) {
            if (LOG_LEVEL >= 1) console.log(msg);
        }
    }));

    // toggle USB connection
    nw.App.registerGlobalHotKey(new nw.Shortcut({
        key : "Ctrl+Shift+U",
        active : function() {
            USBOff('toggle');
        },
        failed : function(msg) {
            if (LOG_LEVEL >= 1) console.log(msg);
        }
    }));

    // switch to en language
    nw.App.registerGlobalHotKey(new nw.Shortcut({
        key : "Ctrl+Shift+1",
        active : function() {
            let ok = mainwin.eval(null,`confirm("${_('切換至英文介面')}");`);
            if (ok !== true) return;
            currentLang = 'en';
            mainwin.eval(null,`window.location.href = "${DEFAULT_URL}?lang=${currentLang}";`);
        },
        failed : function(msg) {
            if (LOG_LEVEL >= 1) console.log(msg);
        }
    }));
    // switch to zh-hant language
    nw.App.registerGlobalHotKey(new nw.Shortcut({
        key : "Ctrl+Shift+2",
        active : function() {
            let ok = mainwin.eval(null,`confirm("${_('切換至正體中文介面')}");`);
            if (ok !== true) return;
            currentLang = 'zh-hant';
            mainwin.eval(null,`window.location.href = "${DEFAULT_URL}?lang=${currentLang}";`);
        },
        failed : function(msg) {
            if (LOG_LEVEL >= 1) console.log(msg);
        }
    }));
    // switch to zh-hans language
    nw.App.registerGlobalHotKey(new nw.Shortcut({
        key : "Ctrl+Shift+3",
        active : function() {
            let ok = mainwin.eval(null,`confirm("${_('切換至簡體中文介面')}");`);
            if (ok !== true) return;
            currentLang = 'zh-hans';
            mainwin.eval(null,`window.location.href = "${DEFAULT_URL}?lang=${currentLang}";`);
        },
        failed : function(msg) {
            if (LOG_LEVEL >= 1) console.log(msg);
        }
    }));

    win.on('loaded', () => {
        updateTitle(null);  // reflash title message
        setTimeout(() => {
            updateTitle(null);  // reflash title message again due to timing issue
            if (deviceId) {
                reportToWebPage({ device: deviceId, version:  fwVersion});
            } else {
                reportToWebPage({ device: '' });
            }

            // Prompt manually update webbit
            if (manuallyUpdateNotify) {
                let ok = mainwin.eval(null,`confirm("${_('WebBit已更新，但部分功能無法線上更新，請下載新版重新安裝。\\n開啟安裝程式下載網頁？')}");`);
                if (ok === true) {
                    nw.Shell.openExternal(INSTALLER_PAGE_URL);
                }
            }
        }, 3000);
    });

    // Release the 'win' object here after the new window is closed.
    win.on('closed', function () {
        win = null;
    });

    // Listen to main window's close event
    nw.Window.get().on('close', function () {
        // Hide the window to give user the feeling of closing immediately
        this.hide();

        // If the new window is still open then close it.
        if (win !== null) {
            win.close(true);
        }

        // After closing the new window, close the main window.
        this.close(true);
    });
});

function convertArrayToArrayBuffer(arr) {
    let bufView = new Uint8Array(arr.length);
    for (let i = 0; i < arr.length; i++) {
        bufView[i] = arr[i];
    }
    return bufView.buffer;
}

function convertArrayBufferToArray(buf) {
    let arr = [];
    let bufView = new Uint8Array(buf);
    for (let i = 0; i < bufView.length; i++) {
        arr.push(bufView[i]);
    }
    return arr;
};

const START_SYSEX = 0xF0;
const END_SYSEX = 0xF7;
const REPORT_FIRMWARE = 0x79;
const CAPABILITY_QUERY = 0x6B;
const ANALOG_MAPPING_QUERY = 0x69;
const SYSEX_RESET = 0xFF;
const msgRebootDevice = convertArrayToArrayBuffer([0xf0, 0x0e, 0x04, 0xf7]);
const msgQueryDeviceId = convertArrayToArrayBuffer([0xf0, 0x0e, 0x0c, 0xf7]);
const msgQueryVersion = convertArrayToArrayBuffer([0xf0, 0x0e, 0x07, 0xf7]);
const msgReportFirmware = Buffer.from([
    0xf0, 0x79, 0x02, 0x05, 0x45, 0x00, 0x53, 0x00, 0x50, 0x00, 0x33, 0x00,
    0x32, 0x00, 0x46, 0x00, 0x69, 0x00, 0x72, 0x00, 0x6d, 0x00, 0x61, 0x00,
    0x74, 0x00, 0x61, 0x00, 0x49, 0x00, 0x6d, 0x00, 0x70, 0x00, 0x6c, 0x00,
    0xf7
]);
const msgQueryCapabilities = Buffer.from([
    0xf0, 0x6c, 0x00, 0x01, 0x01, 0x01, 0x02, 0x0c, 0x03, 0x0c, 0x04, 0x0e, 0x7f, 0x00, 0x01, 0x01,
    0x01, 0x03, 0x0c, 0x04, 0x0e, 0x7f, 0x00, 0x01, 0x01, 0x01, 0x02, 0x0c, 0x03, 0x0c, 0x04, 0x0e,
    0x7f, 0x00, 0x01, 0x01, 0x01, 0x03, 0x0c, 0x04, 0x0e, 0x7f, 0x00, 0x01, 0x01, 0x01, 0x02, 0x0c,
    0x03, 0x0c, 0x04, 0x0e, 0x7f, 0x00, 0x01, 0x01, 0x01, 0x03, 0x0c, 0x04, 0x0e, 0x7f, 0x03, 0x0c,
    0x7f, 0x03, 0x0c, 0x7f, 0x03, 0x0c, 0x7f, 0x03, 0x0c, 0x7f, 0x03, 0x0c, 0x7f, 0x03, 0x0c, 0x7f,
    0x00, 0x01, 0x01, 0x01, 0x02, 0x0c, 0x03, 0x0c, 0x04, 0x0e, 0x7f, 0x00, 0x01, 0x01, 0x01, 0x02,
    0x0c, 0x03, 0x0c, 0x04, 0x0e, 0x7f, 0x00, 0x01, 0x01, 0x01, 0x02, 0x0c, 0x03, 0x0c, 0x04, 0x0e,
    0x7f, 0x00, 0x01, 0x01, 0x01, 0x02, 0x0c, 0x03, 0x0c, 0x04, 0x0e, 0x7f, 0x00, 0x01, 0x01, 0x01,
    0x03, 0x0c, 0x04, 0x0e, 0x7f, 0x00, 0x01, 0x01, 0x01, 0x03, 0x0c, 0x04, 0x0e, 0x7f, 0x00, 0x01,
    0x01, 0x01, 0x03, 0x0c, 0x04, 0x0e, 0x7f, 0x00, 0x01, 0x01, 0x01, 0x03, 0x0c, 0x04, 0x0e, 0x7f,
    0x00, 0x01, 0x01, 0x01, 0x03, 0x0c, 0x04, 0x0e, 0x7f, 0x00, 0x01, 0x01, 0x01, 0x03, 0x0c, 0x04,
    0x0e, 0x7f, 0x00, 0x01, 0x01, 0x01, 0x03, 0x0c, 0x04, 0x0e, 0x7f, 0x00, 0x01, 0x01, 0x01, 0x03,
    0x0c, 0x04, 0x0e, 0x7f, 0x00, 0x01, 0x01, 0x01, 0x03, 0x0c, 0x04, 0x0e, 0x7f, 0x00, 0x01, 0x01,
    0x01, 0x02, 0x0c, 0x03, 0x0c, 0x04, 0x0e, 0x7f, 0x00, 0x01, 0x01, 0x01, 0x02, 0x0c, 0x03, 0x0c,
    0x04, 0x0e, 0x7f, 0x00, 0x01, 0x01, 0x01, 0x02, 0x0c, 0x03, 0x0c, 0x04, 0x0e, 0x7f, 0x00, 0x01,
    0x01, 0x01, 0x03, 0x0c, 0x04, 0x0e, 0x7f, 0x00, 0x01, 0x01, 0x01, 0x03, 0x0c, 0x04, 0x0e, 0x7f,
    0x00, 0x01, 0x01, 0x01, 0x03, 0x0c, 0x04, 0x0e, 0x7f, 0x00, 0x01, 0x01, 0x01, 0x03, 0x0c, 0x04,
    0x0e, 0x7f, 0x00, 0x01, 0x01, 0x01, 0x02, 0x0c, 0x03, 0x0c, 0x04, 0x0e, 0x7f, 0x00, 0x01, 0x01,
    0x01, 0x02, 0x0c, 0x03, 0x0c, 0x04, 0x0e, 0x7f, 0x00, 0x01, 0x01, 0x01, 0x02, 0x0c, 0x04, 0x0e,
    0x7f, 0x00, 0x01, 0x01, 0x01, 0x02, 0x0c, 0x04, 0x0e, 0x7f, 0x02, 0x0c, 0x7f, 0x7f, 0x7f, 0x02,
    0x0c, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f,
    0x7f, 0x7f, 0xf7
]);
const msgQueryAnalogMapping = Buffer.from([
    0xf0, 0x6a, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f,
    0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f,
    0x7f, 0x7f, 0x04, 0x05, 0x06, 0x07, 0x00, 0x7f, 0x7f, 0x03, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f,
    0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0xf7
]);

// keep alive
setInterval(() => {
    if (isUSBOff === true || portId === null || deviceId.length === 0) return;
    if (LOG_LEVEL >= 2) console.log('Keep alive ping');
    serialSend(portId, msgQueryDeviceId);
}, 3000);

const server = http.createServer(function (request, response) {
    if (LOG_LEVEL >= 1) console.log((new Date()) + ' Received request for ' + request.url);
    response.writeHead(404);
    response.end();
});
server.listen(8080, 'localhost', function () {
    if (LOG_LEVEL >= 1) console.log((new Date()) + ' Server is listening on port 8080');
});

const wsServer = new WebSocketServer({
    httpServer: server,
    // You should not use autoAcceptConnections for production
    // applications, as it defeats all standard cross-origin protection
    // facilities built into the protocol and the browser.  You should
    // *always* verify the connection's origin and decide whether or not
    // to accept it.
    autoAcceptConnections: false
});

function originIsAllowed(origin) {
    // put logic here to detect whether the specified origin is allowed.
    return true;
}
wsServer.on('request', function (request) {
    if (!originIsAllowed(request.origin)) {
        // Make sure we only accept requests from an allowed origin
        request.reject();
        if (LOG_LEVEL >= 1) console.log((new Date()) + ' Connection from origin ' + request.origin + ' rejected.');
        return;
    }

    if (portId === null) {
        if (LOG_LEVEL >= 1) console.log('Board not found!');
        return;
    }

    wsConnection = request.accept(null, request.origin);
    if (LOG_LEVEL >= 1) console.log((new Date()) + ' Connection accepted.');

    wsConnection.on('message', function (message) {
        let buf = message.binaryData;
        if (LOG_LEVEL >= 2) console.log('Received Binary Message of ' + buf.length + ' bytes');
        if (LOG_LEVEL >= 2) console.log(buf);

        if (buf.length === 3 && buf[0] === START_SYSEX && buf[2] === END_SYSEX) {
            switch (buf[1]) {
                case REPORT_FIRMWARE:
                    wsConnection.sendBytes(msgReportFirmware);
                    break;
                case CAPABILITY_QUERY:
                    wsConnection.sendBytes(msgQueryCapabilities);
                    break;
                case ANALOG_MAPPING_QUERY:
                    wsConnection.sendBytes(msgQueryAnalogMapping);
                    break;
            }
        } else if (buf[0] === SYSEX_RESET && (buf[1] & 0xF0) === 0xD0) {
            for (let i = 1; i < buf.length; i += 2) {
                setTimeout(() => {
                    wsConnection.sendBytes(Buffer.from([buf[1] & 0x90, 0, 0]));
                }, 100);
            }
        }
        try {
            serialSend(portId, convertArrayToArrayBuffer(buf));
        } catch (error) {}
    });
    wsConnection.on('close', function (reasonCode, description) {
        if (LOG_LEVEL >= 2) console.log((new Date()) + ' Peer ' + wsConnection.remoteAddress + ' disconnected.');
        // port.close();
    });
});

let serialDatabuf = [];
chrome.serial.onReceive.addListener(info => {
    let arrData = convertArrayBufferToArray(info.data);
    if (LOG_LEVEL >= 2) console.log('Received data from ' + info.connectionId + ': ' + JSON.stringify(arrData));        
    // received deviceId?
    if (portId === null && arrData[0] === 0xf0 && arrData[1] === 0x0e && arrData[2] === 0x0c && arrData[arrData.length - 1] === 0xf7) {
        portId = info.connectionId;
        for (let i = 3; i < (arrData.length - 1); i++) {
            deviceId += String.fromCharCode(arrData[i]);
        }
        if (deviceId === '') {
            deviceId = _('未知 ID');
        }
        updateTitle(_('裝置 [{0}] 使用 USB 連線成功', deviceId));
        // get firmware version
        setTimeout(() => {
            if (LOG_LEVEL >= 1) console.log('Sent msgQueryVersion: ' + portId + JSON.stringify(msgQueryVersion));
            serialSend(portId, msgQueryVersion);
        }, 1);
    } else if (arrData[0] === 0xf0 && arrData[1] === 0x71) {    // first part for version data
        if (arrData[arrData.length - 1] === 0xf7) {
            let dataString = '';
            for (let i = 2; i < (arrData.length - 1); i+=2) {
                dataString += String.fromCharCode(arrData[i]);
            }
            fwVersion = dataString.split(',')[0];
        } else {
            serialDatabuf = arrData.slice();
        }
    } else if (serialDatabuf.length > 0 && arrData[arrData.length - 1] === 0xf7) {  // second part of version data
        serialDatabuf = serialDatabuf.concat(arrData);
        let dataString = '';
        // this data payload is seens by UINT16 encoding
        for (let i = 2; i < (serialDatabuf.length - 1); i+=2) {
            dataString += String.fromCharCode(serialDatabuf[i]);
        }
        serialDatabuf = [];
        fwVersion = dataString.split(',')[0];   // first column of the message is version
        if (LOG_LEVEL >= 1) console.log(fwVersion);
        updateTitle(_('裝置 [{0}] 版本 [{1}] 使用 USB 連線成功', deviceId, fwVersion));
        reportToWebPage({ device: deviceId, version:  fwVersion});
        checkNewFirmware();
    } else if (wsConnection !== null) {
        // send to blockly
        wsConnection.sendBytes(Buffer.from(arrData));
    }
});

function scanBoard() {
    if (isUSBOff) {   // USB connection is off
        updateTitle(_('USB 連線已關閉'));
        return;
    }
    if (portId) return;     // already connected
    if (LOG_LEVEL >= 2) console.log('Scan board...');
    updateTitle(_('xxxxxxxx掃描 USB 裝置...'));
    newFirmwareAvailabled = '';
    chrome.serial.getDevices(ports => {
        ports.forEach(port => {
            if (LOG_LEVEL >= 2) console.log('Detected serial port: ' + JSON.stringify(port));
            if (port.displayName) {
                try {
                    chrome.serial.connect(port.path, {
                        bitrate: 115200
                    }, connectionInfo => {
                        if (connectionInfo) {
                            portPaths[connectionInfo.connectionId] = port.path;
                            setTimeout(() => {
                                if (LOG_LEVEL >= 2) console.log('Sent msgQueryDeviceId: ' + connectionInfo.connectionId + JSON.stringify(msgQueryDeviceId));
                                serialSend(connectionInfo.connectionId, msgQueryDeviceId);
                            }, 500);
                        } else {    // connect fail, disconnect all then try again later
                            chrome.serial.getConnections(connections=>{
                                connections.forEach(c => {
                                    chrome.serial.disconnect(c.connectionId, result=>{});
                                });
                            })
                        }
                    });
                } catch (error) {}
            }
        });
    });
    setTimeout(scanBoard, 3000);
}
scanBoard();

chrome.serial.onReceiveError.addListener(info => {
    if (LOG_LEVEL >= 1) console.log('ReceiveError from ' + info.connectionId);
    if (portId === info.connectionId) {
        if (LOG_LEVEL >= 1) console.log('Reset serial connection ' + portId);
        portId = null;
        deviceId = '';
        scanBoard();
    }
});
