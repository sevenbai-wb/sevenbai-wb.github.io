'use strict';

goog.provide('Blockly.Blocks.blockly-edu');
goog.require('Blockly.Blocks');

var mainUrl = 'https://tutorials.webduino.io/zh-tw/docs/';
var utmUrl = '?utm_source=cloud-blockly&utm_medium=contextMenu&utm_campaign=tutorials';


Blockly.Blocks['variables_change'] = {
  init: function () {
    this.appendValueInput("var_")
      .setCheck(null)
      .appendField(new Blockly.FieldVariable("變數"), "name_")
      .appendField("改變");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(330);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

//把一些分散的邏輯集中到邏輯區塊內
Blockly.Blocks['logic_is_empty'] = {
  init: function () {
    this.appendValueInput("val_")
      .setCheck(null);
    this.appendDummyInput()
      .appendField("為空 ( 沒有值 )");
    this.setOutput(true, null);
    this.setColour(210);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['logic_is_even'] = {
  init: function () {
    this.appendValueInput("val_")
      .setCheck(null);
    this.appendDummyInput()
      .appendField("是")
      .appendField(new Blockly.FieldDropdown([["偶數", "even"], ["奇數", "odd"], ["整數", "integer"], ["數字有小數點", "float"], ["文字", "string"], ["陣列", "array"]]), "type_");
    this.setOutput(true, null);
    this.setColour(210);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

//新增陣列積木，改善原本的問題
Blockly.Blocks['lists_get_2'] = {
  init: function () {
    this.appendValueInput("val_")
      .setCheck(null)
      .appendField("自陣列");
    this.menu();
    this.setInputsInline(true);
    this.setOutput(true, null);
    this.setColour(260);
    this.setTooltip("");
    this.setHelpUrl("");
  },
  dynamic1: function () {
    this.removeInput('num_');
    this.removeInput('dynamic_Dummy_');
    this.appendDummyInput('dynamic_Dummy_')
      .appendField("項目");
  },
  dynamic2: function () {
    this.removeInput('dynamic_Dummy_');
    this.appendValueInput("num_")
      .setCheck(null);
    this.appendDummyInput('dynamic_Dummy_')
      .appendField("個項目");
  },
  menu: function () {
    let this_ = this;
    let menuType_ = 0;
    let menuItem = new Blockly.FieldDropdown([["第", "num"], ["倒數第", "endnum"], ["第一個", "first"], ["最後一個", "last"], ["隨機", "random"]], function (value) {
      if (value.indexOf('num') == -1) {
        if (menuType_ == 0) {
          this_.dynamic1();
          menuType_ = 1;
        }
      } else {
        if (menuType_ == 1) {
          this_.dynamic2();
          menuType_ = 0;
        }
      }
    });
    this.appendDummyInput('pos_input_')
      .appendField(new Blockly.FieldDropdown([["取得", "get"], ["取得並移除", "getAndRemove"]]), "type_")
      .appendField(menuItem, "pos_");
    this.appendValueInput("num_")
      .setCheck(null);
    this.appendDummyInput('dynamic_Dummy_')
      .appendField("個項目");
    this_ = this;
    setTimeout(function () {
      let value_ = this_.inputList[1].fieldRow[1].value_;
      if (value_.indexOf('num') == -1) {
        this_.removeInput('num_');
        this_.removeInput('dynamic_Dummy_');
        this_.appendDummyInput('dynamic_Dummy_')
          .appendField("項目");
        menuType_ = 1;
      }
    });
  }
};

Blockly.Blocks['lists_set_2'] = {
  init: function () {
    this.appendDummyInput("head_")
      .appendField("自陣列");
    this.appendValueInput("name_")
      .setCheck(null);
    this.menu();
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(260);
    this.setTooltip("");
    this.setHelpUrl("");
  },
  menu: function () {
    let this_ = this;
    let isNum = 1;
    let isRemove = 0;
    let menuType_ = 'num';
    let menuType2_ = 'set';
    let menuItem = new Blockly.FieldDropdown([["第", "num"], ["倒數第", "endnum"], ["第一個", "first"], ["最後一個", "last"], ["隨機", "random"]], function (value) {
      menuType_ = value;
      if (menuType_.indexOf('num') < 0) {
        if (isNum == 1) {
          isNum = 0;
          this_.removeInput('dynamic_Dummy_');
          this_.removeInput('num_');
          if (isRemove == 0) {
            this_.appendDummyInput('dynamic_Dummy_')
              .appendField("項目為");
            this_.moveInputBefore('dynamic_Dummy_', 'val_');
          } else {
            this_.appendDummyInput('dynamic_Dummy_')
              .appendField("項目");
          }
        }
      } else {
        if (isNum == 0) {
          isNum = 1;
          this_.removeInput('dynamic_Dummy_');
          this_.appendValueInput("num_")
            .setCheck(null);
          if (isRemove == 0) {
            this_.appendDummyInput('dynamic_Dummy_')
              .appendField("個項目為");
            this_.moveInputBefore('dynamic_Dummy_', 'val_');
            this_.moveInputBefore('num_', 'dynamic_Dummy_');
          } else {
            this_.appendDummyInput('dynamic_Dummy_')
              .appendField("個項目");
          }
        }
      }
    });
    let menuItem2 = new Blockly.FieldDropdown([["設定", "set"], ["插入", "insert"], ["移除", "remove"]], function (value) {
      menuType2_ = value;
      if (menuType2_ == 'remove') {
        if (isRemove == 0) {
          isRemove = 1;
          this_.removeInput('dynamic_Dummy_');
          this_.removeInput('val_');
          if (isNum == 1) {
            this_.appendDummyInput('dynamic_Dummy_')
              .appendField("個項目");
          } else {
            this_.appendDummyInput('dynamic_Dummy_')
              .appendField("項目");
          }
        }
      } else {
        if (isRemove == 1) {
          isRemove = 0;
          this_.removeInput('dynamic_Dummy_');
          if (isNum == 1) {
            this_.appendDummyInput('dynamic_Dummy_')
              .appendField("個項目為");
          } else {
            this_.appendDummyInput('dynamic_Dummy_')
              .appendField("項目為");
          }
          this_.appendValueInput("val_")
            .setCheck(null);
        }
      }
    });

    this.appendDummyInput('type_input_')
      .appendField(menuItem2, "type_")
      .appendField(menuItem, "pos_");
    this.appendValueInput("num_")
      .setCheck(null);
    this.appendDummyInput('dynamic_Dummy_')
      .appendField("個項目為");
    this.appendValueInput("val_")
      .setCheck(null);
    this_ = this;
    setTimeout(function () {
      menuType_ = this_.inputList[2].fieldRow[1].value_;
      menuType2_ = this_.inputList[2].fieldRow[0].value_;
      if (menuType2_ == 'remove') {
        this_.removeInput('dynamic_Dummy_');
        this_.removeInput('val_');
        isRemove = 1;
        if (menuType_.indexOf('num') < 0) {
          isNum = 0;
          this_.removeInput('num_');
          this_.appendDummyInput('dynamic_Dummy_')
            .appendField("項目");
        } else {
          isNum = 1;
          this_.appendDummyInput('dynamic_Dummy_')
            .appendField("個項目");
        }
      } else {
        isRemove = 0;
        if (menuType_.indexOf('num') < 0) {
          isNum = 0;
          this_.removeInput('dynamic_Dummy_');
          this_.removeInput('num_');
          this_.appendDummyInput('dynamic_Dummy_')
            .appendField("項目為");
          this_.moveInputBefore('dynamic_Dummy_', 'val_');
        } else {
          isNum = 1;
        }
      }
    });
  }
};

Blockly.Blocks['lists_indexOf_2'] = {
  init: function () {
    this.appendValueInput("name_")
      .setCheck(null)
      .appendField("自陣列");
    this.appendValueInput("val_")
      .setCheck(null)
      .appendField("找出")
      .appendField(new Blockly.FieldDropdown([["第一個", "indexOf"], ["最後一個", "lastIndexOf"]]), "type_")
      .appendField("項目出現");
    this.appendDummyInput()
      .appendField("的位置");
    this.setInputsInline(true);
    this.setOutput(true, null);
    this.setColour(260);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['lists_sort_2'] = {
  init: function () {
    this.appendValueInput("name_")
      .setCheck(null)
      .appendField("自陣列");
    this.appendDummyInput()
      .appendField("按照")
      .appendField(new Blockly.FieldDropdown([["數字", "NUMERIC"], ["字母", "TEXT"], ["字母 ( 忽略大小寫 )", "IGNORE_CASE"]]), "type1_")
      .appendField("進行")
      .appendField(new Blockly.FieldDropdown([["升序", '1'], ["降序", '-1']]), "type2_")
      .appendField("排列");
    this.setInputsInline(true);
    this.setOutput(true, null);
    this.setColour(260);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['lists_split_2'] = {
  init: function () {
    this.appendValueInput("name_")
      .setCheck(null)
      .appendField("在");
    this.appendValueInput("mark_")
      .setCheck(null)
      .appendField("用分隔符");
    this.appendDummyInput()
      .appendField(new Blockly.FieldDropdown([["把文字拆成陣列", "split"], ["把陣列合併為文字", "join"]]), "type_");
    this.setInputsInline(true);
    this.setOutput(true, null);
    this.setColour(260);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

//修正文字積木錯誤

Blockly.Blocks['text_indexOf_2'] = {
  init: function () {
    this.appendValueInput("name_")
      .setCheck(null)
      .appendField("在字串");
    this.appendDummyInput()
      .appendField("找出")
      .appendField(new Blockly.FieldDropdown([["第一個", "indexOf"], ["最後一個", "lastIndexOf"]]), "type_")
      .appendField("出現字串");
    this.appendValueInput("val_")
      .setCheck(null);
    this.appendDummyInput()
      .appendField("的位置");
    this.setOutput(true, null);
    this.setColour(160);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['text_charAt_2'] = {
  init: function () {
    this.appendValueInput("name_")
      .setCheck(null)
      .appendField("取得字串");
    this.menu();
    this.setInputsInline(true);
    this.setOutput(true, null);
    this.setColour(160);
    this.setTooltip("");
    this.setHelpUrl("");
  },
  dynamic1: function () {
    this.removeInput('num_');
    this.removeInput('dynamic_Dummy_');
    this.appendDummyInput('dynamic_Dummy_')
      .appendField("字元");
  },
  dynamic2: function () {
    this.removeInput('dynamic_Dummy_');
    this.appendValueInput("num_")
      .setCheck(null);
    this.appendDummyInput('dynamic_Dummy_')
      .appendField("個字元");
  },
  menu: function () {
    let this_ = this;
    let menuType_ = 0;
    let menuItem = new Blockly.FieldDropdown([["第", "num"], ["倒數第", "endnum"], ["第一個", "first"], ["最後一個", "last"], ["隨機", "random"]], function (value) {
      if (value.indexOf('num') == -1) {
        if (menuType_ == 0) {
          this_.dynamic1();
          menuType_ = 1;
        }
      } else {
        if (menuType_ == 1) {
          this_.dynamic2();
          menuType_ = 0;
        }
      }
    }); this.appendDummyInput()
      .appendField("的")
      .appendField(menuItem, "type_");
    this.appendValueInput("num_")
      .setCheck(null);
    this.appendDummyInput('dynamic_Dummy_')
      .appendField("個字元");
    this_ = this;
    setTimeout(function () {
      let value_ = this_.inputList[1].fieldRow[1].value_;
      if (value_.indexOf('num') == -1) {
        this_.removeInput('num_');
        this_.removeInput('dynamic_Dummy_');
        this_.appendDummyInput('dynamic_Dummy_')
          .appendField("字元");
        menuType_ = 1;
      }
    });
  }
};

Blockly.Blocks['text_getSubstring_2'] = {
  init: function () {
    this.appendValueInput("name_")
      .setCheck(null)
      .appendField("取得字串");
    this.menu();
    this.setInputsInline(true);
    this.setOutput(true, null);
    this.setColour(160);
    this.setTooltip("");
    this.setHelpUrl("");
  },
  menu: function () {
    let this_ = this;
    let menuType1_ = 0;
    let menuType2_ = 0;
    let menuItem = new Blockly.FieldDropdown([["第", "num"], ["倒數第", "endnum"], ["第一個", "first"]], function (value) {
      if (value.indexOf('num') == -1) {
        if (menuType1_ == 0) {
          this_.removeInput('num1_');
          this_.removeInput('dynamic_Dummy1_');
          this_.appendDummyInput('dynamic_Dummy1_')
            .appendField("字元到");
          this_.moveInputBefore('dynamic_Dummy1_', 'dynamic_type2_');
          menuType1_ = 1;
        }
      } else {
        if (menuType1_ == 1) {
          this_.removeInput('dynamic_Dummy1_');
          this_.appendValueInput("num1_")
            .setCheck(null);
          this_.appendDummyInput('dynamic_Dummy1_')
            .appendField("個字元到");
          this_.moveInputBefore('dynamic_Dummy1_', 'dynamic_type2_');
          this_.moveInputBefore('num1_', 'dynamic_Dummy1_');
          menuType1_ = 0;
        }
      }
    });
    let menuItem2 = new Blockly.FieldDropdown([["第", "num"], ["倒數第", "endnum"], ["最後一個", "last"]], function (value) {
      if (value.indexOf('num') == -1) {
        if (menuType2_ == 0) {
          this_.removeInput('num2_');
          this_.removeInput('dynamic_Dummy2_');
          this_.appendDummyInput('dynamic_Dummy2_')
            .appendField("字元");
          menuType2_ = 1;
        }
      } else {
        if (menuType2_ == 1) {
          this_.removeInput('dynamic_Dummy2_');
          this_.appendValueInput("num2_")
            .setCheck(null);
          this_.appendDummyInput('dynamic_Dummy2_')
            .appendField("個字元");
          menuType2_ = 0;
        }
      }
    });
    this.appendDummyInput("dynamic_type1_")
      .appendField("的")
      .appendField(menuItem, "type1_");
    this.appendValueInput("num1_")
      .setCheck(null);
    this.appendDummyInput("dynamic_Dummy1_")
      .appendField("個字元到");
    this.appendDummyInput("dynamic_type2_")
      .appendField(menuItem2, "type2_");
    this.appendValueInput("num2_")
      .setCheck(null);
    this.appendDummyInput("dynamic_Dummy2_")
      .appendField("個字元");
    this_ = this;
    setTimeout(function () {
      let value1_ = this_.inputList[1].fieldRow[1].value_;
      let value2_ = this_.inputList[4].fieldRow[0].value_;
      if (value1_.indexOf('num') == -1) {
        this_.removeInput('num1_');
        this_.removeInput('dynamic_Dummy1_');
        this_.appendDummyInput('dynamic_Dummy1_')
          .appendField("字元到");
        this_.moveInputBefore('dynamic_Dummy1_', 'dynamic_type2_');
        menuType1_ = 1;
      }
      if (value2_.indexOf('num') == -1) {
        this_.removeInput('num2_');
        this_.removeInput('dynamic_Dummy2_');
        this_.appendDummyInput('dynamic_Dummy2_')
          .appendField("字元");
        menuType2_ = 1;
      }
    });
  }
};

Blockly.Blocks['text_replace'] = {
  init: function () {
    this.appendValueInput("name_")
      .setCheck(null)
      .appendField("把字串");
    this.appendDummyInput()
      .appendField("的")
      .appendField(new Blockly.FieldDropdown([["第一個", "first"], ["所有", "all"]]), "type_");
    this.appendValueInput("input_")
      .setCheck(null);
    this.appendDummyInput()
      .appendField("取代為");
    this.appendValueInput("output_")
      .setCheck(null);
    this.setInputsInline(true);
    this.setOutput(true, null);
    this.setColour(160);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['text_append_2'] = {
  init: function () {
    this.appendValueInput("name_")
      .setCheck(null)
      .appendField("在字串");
    this.appendValueInput("text_")
      .setCheck(null)
      .appendField("後方加入文字");
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(160);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

//增加長度的積木

Blockly.Blocks['lists_length_2'] = {
  init: function () {
    this.appendValueInput("name_")
      .setCheck("Array")
      .appendField("陣列");
    this.appendDummyInput()
      .appendField("的長度");
    this.setOutput(true, null);
    this.setColour(260);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['text_length_2'] = {
  init: function () {
    this.appendValueInput("name_")
      .setCheck("String")
      .appendField("字串");
    this.appendDummyInput()
      .appendField("的長度");
    this.setOutput(true, null);
    this.setColour(160);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};


//簡化版無窮迴圈積木
Blockly.Blocks['controls_loop_forever'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("重複無限次，背景執行")
      .appendField(new Blockly.FieldCheckbox("FALSE"), "async");
    this.appendStatementInput("do_")
      .setCheck(null)
      .appendField("執行");
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(110);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['controls_loop_forever_while_do'] = {
  init: function () {
    this.appendValueInput("val_")
      .setCheck(null)
      .appendField("如果");
    this.appendDummyInput()
      .appendField("就重複無限次，背景執行")
      .appendField(new Blockly.FieldCheckbox("FALSE"), "async");
    this.appendStatementInput("do_")
      .setCheck(null)
      .appendField("執行");
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(110);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['controls_loop_stop'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("停止")
      .appendField(new Blockly.FieldDropdown([["所有的", "all"], ["這個", "this"]]), "type_")
      .appendField("重複");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(110);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['controls_repeat_ext_can_stop'] = {
  init: function () {
    this.appendValueInput("times_")
      .setCheck(null)
      .appendField("重複");
    this.appendDummyInput()
      .appendField("次，背景執行")
      .appendField(new Blockly.FieldCheckbox("FALSE"), "async");
    this.appendStatementInput("do_")
      .setCheck(null)
      .appendField("執行");
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(110);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['controls_for_can_stop'] = {
  init: function () {
    this.appendValueInput("from_")
      .setCheck(null)
      .appendField("計數")
      .appendField(new Blockly.FieldVariable("i"), "item_")
      .appendField("從");
    this.appendValueInput("to_")
      .setCheck(null)
      .appendField("到");
    this.appendValueInput("num_")
      .setCheck(null)
      .appendField("每隔");
    this.appendDummyInput()
      .appendField("背景執行")
      .appendField(new Blockly.FieldCheckbox("FALSE"), "async");
    this.appendStatementInput("do_")
      .setCheck(null)
      .appendField("執行");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(110);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['controls_foreach_can_stop'] = {
  init: function () {
    this.appendValueInput("array_")
      .setCheck(null)
      .appendField("取出每個")
      .appendField(new Blockly.FieldVariable("i"), "item_")
      .appendField("自陣列");
    this.appendDummyInput()
      .appendField("背景執行")
      .appendField(new Blockly.FieldCheckbox("FALSE"), "async");
    this.appendStatementInput("do_")
      .setCheck(null)
      .appendField("執行");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(110);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

//把除號放大
Blockly.Blocks['math_modulo_big_icon'] = {
  init: function () {
    this.appendValueInput("a_")
      .setCheck(null)
      .appendField("取餘數自");
    this.appendValueInput("b_")
      .setCheck(null)
      .appendField(new Blockly.FieldImage("media/icon-divided.png", 12, 12, "÷"));
    this.setInputsInline(true);
    this.setOutput(true, null);
    this.setColour(230);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

//簡化鍵盤事件積木
Blockly.Blocks['bit_document_keycode'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("當鍵盤")
      .appendField(new Blockly.FieldDropdown([
        ["按下", "keyDownCode"],
        ["放開", "keyUpCode"]
      ]), "event_")
      .appendField(new Blockly.FieldDropdown([
        ["A", "65"],
        ["B", "66"],
        ["C", "67"],
        ["D", "68"],
        ["E", "69"],
        ["F", "70"],
        ["G", "71"],
        ["H", "72"],
        ["I", "73"],
        ["J", "74"],
        ["K", "75"],
        ["L", "76"],
        ["M", "77"],
        ["N", "78"],
        ["O", "79"],
        ["P", "80"],
        ["Q", "81"],
        ["R", "82"],
        ["S", "83"],
        ["T", "84"],
        ["U", "85"],
        ["V", "86"],
        ["W", "87"],
        ["X", "88"],
        ["Y", "89"],
        ["Z", "90"],
        ["空白鍵", "32"],
        ["enter", "13"],
        ["上 ▲", "38"],
        ["下 ▼", "40"],
        ["左 ◀", "37"],
        ["右 ▶", "39"],
        ["0", "48"],
        ["1", "49"],
        ["2", "50"],
        ["3", "51"],
        ["4", "52"],
        ["5", "53"],
        ["6", "54"],
        ["7", "55"],
        ["8", "56"],
        ["9", "57"],
        ["shift", "16"],
        ["alt", "18"],
        ["ctrl", "17"],
        ["command(R)", "93"],
        ["command(L)", "91"],
        ["tab", "9"],
        ["+ -", "187"],
        ["- _", "189"],
        ["{ [", "219"],
        ["} ]", "221"],
        ["|", "220"],
        ["; :", "186"],
        ["\' \"", "222"],
        ["< ,", "188"],
        ["> .", "190"],
        ["? /", "191"]
      ]), "keycode_");
    this.appendStatementInput("do_")
      .appendField("執行");
    this.setInputsInline(false);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip('');
    this.setColour(10);
    this.setHelpUrl(mainUrl + 'useful/example/toycar-keyboard.html' + utmUrl);
  }
};

Blockly.Blocks['input_text_async'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("在對話框輸入文字");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(10);
    this.setTooltip("");
    this.setHelpUrl("");
    this.setCommentText("輸入文字之後，才會繼續執行下方程式");
  }
};

Blockly.Blocks['input_text_async_val'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("輸入的文字");
    this.setOutput(true, null);
    this.setColour(5);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['input_text'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("在對話框輸入文字");
    this.appendStatementInput("do_")
      .setCheck(null)
      .appendField("執行");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(10);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['input_text_val'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("輸入的文字");
    this.setOutput(true, null);
    this.setColour(5);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['speak_async'] = {
  init: function () {
    this.appendValueInput("text_")
      .setCheck(null)
      .appendField(Blockly.Msg.WEBDUINO_SPEAK_TEXT, "朗讀文字");
    this.appendValueInput("setting_")
      .setAlign(Blockly.ALIGN_RIGHT)
      .setCheck(null)
      .appendField(Blockly.Msg.WEBDUINO_SPEAK_SETTING, "參數設定");
    this.setInputsInline(false);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('');
    this.setColour(40);
    this.setHelpUrl('');
    this.setCommentText("朗讀結束後，才會繼續執行下方程式");
  }
};

Blockly.Blocks['speak_async_setting'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("語言")
      .appendField(new Blockly.FieldDropdown([
        ["中文", "zh-TW"],
        ["英文", "en-US"],
        ["日文", "ja-JP"]
      ]), "lang_")
      .appendField(" 音調")
      .appendField(new Blockly.FieldDropdown([
        ["尖銳", "2"],
        ["高昂", "1.5"],
        ["正常", "1"],
        ["低沈", "0.5"],
        ["沙啞", "0.1"]
      ]), "pitch_")
      .appendField(" 速度")
      .appendField(new Blockly.FieldDropdown([
        ["很快", "2"],
        ["快", "1.5"],
        ["正常", "1"],
        ["慢", "0.7"],
        ["很慢", "0.5"]
      ]), "rate_");
    this.setInputsInline(true);
    this.setOutput(true, null);
    this.setTooltip('');
    this.setColour(45);
    this.setHelpUrl('');
  }
};

/*
88""Yb  dP"Yb     db    88""Yb 8888b.  
88__dP dP   Yb   dPYb   88__dP  8I  Yb 
88""Yb Yb   dP  dP__Yb  88"Yb   8I  dY 
88oodP  YbodP  dP""""Yb 88  Yb 8888Y" 
*/

Blockly.Blocks['board'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("使用")
    this.menu();
    this.appendStatementInput("callbacks_")
      .setCheck(null)
      .appendField("執行");
    this.setInputsInline(true);
    this.setColour(240);
    this.setTooltip("");
    this.setHelpUrl("");
  },
  menu: function () {
    let board_ = 'b' + new Date().getTime();
    let this_ = this;
    let menuText = '';
    let menuItem2 = new Blockly.FieldTextInput(menuText, function (value) {
      menuText = value;
    });
    let menuItem = new Blockly.FieldDropdown([["模擬器", "bit"], ["USB", "usb"], ["Wi-Fi", "wifi"]], function (value) {
      switch (value) {
        case 'bit':
          this_.removeInput('Dummy_device_');
          break;
        case 'wifi':
          if (menuText.length == 0) {
            if (window.boardDeviceId_) {
              menuText = window.boardDeviceId_;
            } else {
              menuText = 'Web:Bit';
            }
            menuItem2 = new Blockly.FieldTextInput(menuText, function (value) {
              menuText = value;
            });
            this_.appendDummyInput('Dummy_device_')
              .appendField(menuItem2, "device_");
          } else {
            this_.appendDummyInput('Dummy_device_')
              .appendField(menuItem2, "device_");
          }
          this_.moveInputBefore('Dummy_device_', 'callbacks_');

          break;
        case 'usb':
          this_.removeInput('Dummy_device_');
          break;
      }
    });
    this.appendDummyInput()
      .appendField(menuItem, "type_")
    this.appendDummyInput('Dummy_control_')
      .appendField("控制");
    this_.appendDummyInput('Dummy_device_')
      .appendField(menuItem2, "device_");
    setTimeout(function () {
      let menuType_ = this_.inputList[1].fieldRow[0].value_;
      switch (menuType_) {
        case 'bit':
          this_.removeInput('Dummy_device_');
          break;
        case 'wifi':
          Code.cloudHostCheck(board_, 'wifi');
          break;
        case 'usb':
          this_.removeInput('Dummy_device_');
          break;
      }
    })
  }
};

/* 
8b    d8    db    888888 88""Yb 88 Yb  dP 
88b  d88   dPYb     88   88__dP 88  YbdP  
88YbdP88  dP__Yb    88   88"Yb  88  dPYb  
88 YY 88 dP""""Yb   88   88  Yb 88 dP  Yb 
*/

Blockly.Blocks['bit_matrix_color_single'] = {
  init: function () {
    this.appendValueInput('led_')
      .setCheck('Number')
      .appendField('矩陣 LED 第');
    this.appendValueInput('color_')
      .setCheck(null)
      .appendField('顆的燈光顏色');
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(250);
    this.setTooltip('');
    this.setHelpUrl('');
  }
};

Blockly.Blocks['bit_matrix_brightness'] = {
  init: function () {
    this.appendValueInput('brightness_')
      .setCheck(null)
      .appendField('矩陣 LED 的亮度為 (0~20)');
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(250);
    this.setTooltip('');
    this.setHelpUrl('');
  }
};

Blockly.Blocks['bit_matrix_off'] = {
  init: function () {
    this.appendDummyInput()
      .appendField('關閉矩陣 LED ( 關燈 )');
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(250);
    this.setTooltip('');
    this.setHelpUrl('');
  }
};

Blockly.Blocks['bit_matrix_character'] = {
  init: function () {
    this.appendValueInput('char_')
      .setCheck(null)
      .appendField('矩陣 LED 顯示一個字');
    this.appendValueInput('color_')
      .setCheck(null)
      .appendField('燈光顏色')
      .setAlign(Blockly.ALIGN_RIGHT);
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(250);
    this.setTooltip('');
    this.setHelpUrl('');
  }
};

Blockly.Blocks['bit_matrix_string_once'] = {
  init: function () {
    this.appendValueInput("str_")
      .setCheck(null)
      .appendField("矩陣 LED 跑馬燈")
      .setAlign(Blockly.ALIGN_RIGHT);
    this.appendValueInput("color_")
      .setCheck(null)
      .appendField("燈光顏色")
      .setAlign(Blockly.ALIGN_RIGHT);
    this.appendDummyInput()
      .appendField("播放")
      .appendField(new Blockly.FieldDropdown([["一次", "1"], ["無限次", "2"]]), "type_")
      .setAlign(Blockly.ALIGN_RIGHT);
    this.appendDummyInput()
      .appendField(' 速度')
      .appendField(new Blockly.FieldDropdown([
        ["快", "0"],
        ["中", "2"],
        ["慢", "4"]
      ]), 'speed_')
      .setAlign(Blockly.ALIGN_RIGHT);
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(250);
    this.setTooltip("");
    this.setHelpUrl("");
    this.setCommentText("若選擇一次，在跑馬燈結束後才會繼續執行下方程式");
  }
};

Blockly.Blocks['bit_matrix_string'] = {
  init: function () {
    this.appendValueInput('str_')
      .setCheck(null)
      .appendField('矩陣 LED 跑馬燈')
      .setAlign(Blockly.ALIGN_RIGHT);
    this.appendValueInput('color_')
      .setCheck(null)
      .appendField('燈光顏色')
      .setAlign(Blockly.ALIGN_RIGHT);
    this.appendDummyInput()
      .appendField('速度')
      .appendField(new Blockly.FieldDropdown([
        ["150", "0"],
        ["200", "1"],
        ["250", "2"],
        ["500", "3"],
        ["1000", "4"]
      ]), 'speed_')
      .appendField("ms")
      .setAlign(Blockly.ALIGN_RIGHT);
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(250);
    this.setTooltip('');
    this.setHelpUrl('');
  }
};

Blockly.Blocks['bit_matrix_color_output'] = {
  init: function () {
    this.appendValueInput("color_input")
      .setCheck(null)
      .appendField('矩陣 LED 燈光為');
    this.setInputsInline(false);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(250);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};


Blockly.Blocks['bit_matrix_color_array'] = {
  init: function () {
    this.appendDummyInput()
      .appendField('繪製圖案')
      .appendField(new Blockly.CustomFieldColour('#ffffff'), 'mcolor_');
    this.appendDummyInput()
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_0_')
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_1_')
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_2_')
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_3_')
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_4_');
    this.appendDummyInput()
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_5_')
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_6_')
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_7_')
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_8_')
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_9_');
    this.appendDummyInput()
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_10_')
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_11_')
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_12_')
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_13_')
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_14_');
    this.appendDummyInput()
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_15_')
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_16_')
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_17_')
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_18_')
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_19_');
    this.appendDummyInput()
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_20_')
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_21_')
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_22_')
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_23_')
      .appendField(new Blockly.CustomFieldCheckbox('#000000'), 'led_24_');
    this.setColour(255);
    this.setOutput(true, null);
    this.setTooltip('');
    this.setHelpUrl('');
  }
};

Blockly.Blocks['bit_matrix_xy'] = {
  init: function () {
    this.appendValueInput("x")
      .setCheck(null)
      .appendField('矩陣 LED')
      .appendField("x")
      .setAlign(Blockly.ALIGN_RIGHT);
    this.appendValueInput("y")
      .setCheck(null)
      .appendField("y")
      .setAlign(Blockly.ALIGN_RIGHT);
    this.appendValueInput("color_input")
      .setCheck(null)
      .appendField('燈光顏色')
      .setAlign(Blockly.ALIGN_RIGHT);
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(250);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};
//圖形產生：https://jsbin.com/yubolugoti/1/edit?html,js,output
//圖形產生 part2：https://jsbin.com/qucofuyaxe/1/edit?html,css,js,output
//圖形產生 part3：https://jsbin.com/winejihewi/1/edit?html,css,js,output
let emoji_list = [
  [' {"class":"bit-matrix-icon icon-55", "title":"☺ ( 笑臉 ) ", "showTitle":"false"}', "0000001010000001000101110"],
  ['{"class":"bit-matrix-icon icon-56", "title":"☹ ( 哭臉 ) ", "showTitle":"false"}', "0000001010000000111010001"],
  ['{"class":"bit-matrix-icon icon-57", "title":"✌🏾 ( 剪刀 ) ", "showTitle":"false"}', "1000101010001001101111011"],
  ['{"class":"bit-matrix-icon icon-58", "title":"✊🏾 ( 石頭 ) ", "showTitle":"false"}', "0111011111111110111001110"],
  ['{"class":"bit-matrix-icon icon-59", "title":"🖐🏾 ( 布 ) ", "showTitle":"false"}', "1010101110111110111010101"],
  ['{"class":"bit-matrix-icon icon-60", "title":"♥", "showTitle":"false"}', "0000001010011100010000000"],
  ['{"class":"bit-matrix-icon icon-32", "title":"❤", "showTitle":"false"}', "0101011111111110111000100"],
  ['{"class":"bit-matrix-icon icon-33", "title":"♡", "showTitle":"false"}', "0101010101100010101000100"],
  ['{"class":"bit-matrix-icon icon-06", "title":"▲", "showTitle":"false"}', "0000000100011101111100000"],
  ['{"class":"bit-matrix-icon icon-07", "title":"▼", "showTitle":"false"}', "0000011111011100010000000"],
  ['{"class":"bit-matrix-icon icon-08", "title":"◀", "showTitle":"false"}', "0001000110011100011000010"],
  ['{"class":"bit-matrix-icon icon-09", "title":"▶", "showTitle":"false"}', "0100001100011100110001000"],
  ['{"class":"bit-matrix-icon icon-10", "title":"◢", "showTitle":"false"}', "0000000001000110011101111"],
  ['{"class":"bit-matrix-icon icon-11", "title":"◣", "showTitle":"false"}', "0000010000110001110011110"],
  ['{"class":"bit-matrix-icon icon-12", "title":"◥", "showTitle":"false"}', "0111100111000110000100000"],
  ['{"class":"bit-matrix-icon icon-13", "title":"◤", "showTitle":"false"}', "1111011100110001000000000"],
  ['{"class":"bit-matrix-icon icon-14", "title":"↑", "showTitle":"false"}', "0010001110101010010000100"],
  ['{"class":"bit-matrix-icon icon-15", "title":"↓", "showTitle":"false"}', "0010000100101010111000100"],
  ['{"class":"bit-matrix-icon icon-16", "title":"←", "showTitle":"false"}', "0010001000111110100000100"],
  ['{"class":"bit-matrix-icon icon-17", "title":"→", "showTitle":"false"}', "0010000010111110001000100"],
  ['{"class":"bit-matrix-icon icon-18", "title":"↖", "showTitle":"false"}', "1110011000101000001000001"],
  ['{"class":"bit-matrix-icon icon-19", "title":"↗", "showTitle":"false"}', "0011100011001010100010000"],
  ['{"class":"bit-matrix-icon icon-20", "title":"↙", "showTitle":"false"}', "0000100010101001100011100"],
  ['{"class":"bit-matrix-icon icon-21", "title":"↘", "showTitle":"false"}', "1000001000001010001100111"],
  ['{"class":"bit-matrix-icon icon-28", "title":"⧓", "showTitle":"false"}', "1000111011111111101110001"],
  ['{"class":"bit-matrix-icon icon-29", "title":"⧗", "showTitle":"false"}', "1111101110001000111011111"],
  ['{"class":"bit-matrix-icon icon-30", "title":"⧔", "showTitle":"false"}', "1000111010111001101010001"],
  ['{"class":"bit-matrix-icon icon-31", "title":"⧕", "showTitle":"false"}', "1000101011001110101110001"],
  ['{"class":"bit-matrix-icon icon-22", "title":"·", "showTitle":"false"}', "0000000000001000000000000"],
  ['{"class":"bit-matrix-icon icon-23", "title":"∶", "showTitle":"false"}', "0000000100000000010000000"],
  ['{"class":"bit-matrix-icon icon-24", "title":"∴", "showTitle":"false"}', "0000000100000000101000000"],
  ['{"class":"bit-matrix-icon icon-25", "title":"∶∶", "showTitle":"false"}', "0000001010000000101000000"],
  ['{"class":"bit-matrix-icon icon-26", "title":"∶·∶", "showTitle":"false"}', "0000001010001000101000000"],
  ['{"class":"bit-matrix-icon icon-27", "title":"⋮⋮", "showTitle":"false"}', "0101000000010100000001010"],
  ['{"class":"bit-matrix-icon icon-34", "title":"□", "showTitle":"false"}', "0000001110010100111000000"],
  ['{"class":"bit-matrix-icon icon-35", "title":"■", "showTitle":"false"}', "0000001110011100111000000"],
  ['{"class":"bit-matrix-icon icon-36", "title":"○", "showTitle":"false"}', "0111010001100011000101110"],
  ['{"class":"bit-matrix-icon icon-37", "title":"◆", "showTitle":"false"}', "0010001110111110111000100"],
  ['{"class":"bit-matrix-icon icon-38", "title":"◇", "showTitle":"false"}', "0010001010100010101000100"],
  ['{"class":"bit-matrix-icon icon-39", "title":"⊡", "showTitle":"false"}', "1111110001101011000111111"],
  ['{"class":"bit-matrix-icon icon-40", "title":"⊞", "showTitle":"false"}', "1111110101111111010111111"],
  ['{"class":"bit-matrix-icon icon-41", "title":"⟐", "showTitle":"false"}', "0010001010101010101000100"],
  ['{"class":"bit-matrix-icon icon-42", "title":"★", "showTitle":"false"}', "0010010101011100101010001"],
  ['{"class":"bit-matrix-icon icon-43", "title":"✔", "showTitle":"false"}', "0000100010101000100000000"],
  ['{"class":"bit-matrix-icon icon-44", "title":"♪", "showTitle":"false"}', "0011000101001001110011100"],
  ['{"class":"bit-matrix-icon icon-45", "title":"♫", "showTitle":"false"}', "0111101001010011101111011"],
  ['{"class":"bit-matrix-icon icon-46", "title":"⌗", "showTitle":"false"}', "0101011111010101111101010"],
  ['{"class":"bit-matrix-icon icon-47", "title":"⚑", "showTitle":"false"}', "0111101111011110100001000"],
  ['{"class":"bit-matrix-icon icon-48", "title":"⊠", "showTitle":"false"}', "1111111011101011101111111"],
  ['{"class":"bit-matrix-icon icon-49", "title":"♀", "showTitle":"false"}', "0111001110001001111100100"],
  ['{"class":"bit-matrix-icon icon-50", "title":"♂", "showTitle":"false"}', "0010100010111011010011100"],
  ['{"class":"bit-matrix-icon icon-51", "title":"※", "showTitle":"false"}', "1010101010101010101010101"],
  ['{"class":"bit-matrix-icon icon-52", "title":"✈", "showTitle":"false"}', "0010010110111111011000100"],
  ['{"class":"bit-matrix-icon icon-53", "title":"♕", "showTitle":"false"}', "1010110101111111000111111"],
  ['{"class":"bit-matrix-icon icon-54", "title":"≡", "showTitle":"false"} ', "1111100000111110000011111"],
  ['{"class":"bit-matrix-icon icon-05", "title":"=", "showTitle":"false"}', "0000011111000001111100000"],
  ['{"class":"bit-matrix-icon icon-01", "title":"+", "showTitle":"false"}', "0010000100111110010000100"],
  ['{"class":"bit-matrix-icon icon-02", "title":"–", "showTitle":"false"}', "0000000000111110000000000"],
  ['{"class":"bit-matrix-icon icon-03", "title":"×", "showTitle":"false"}', "1000101010001000101010001"],
  ['{"class":"bit-matrix-icon icon-04", "title":"÷", "showTitle":"false"}', "0010000000111110000000100"],
  ['{"class":"bit-matrix-icon icon-00", "title":"隨機", "showTitle":"false"} ', "random"]
];


Blockly.Blocks['bit_matrix_emoji'] = {
  init: function () {
    this.appendDummyInput()
      .appendField('圖案')
      .appendField(new Blockly.FieldDropdown(emoji_list), "emoji")
      .setAlign(Blockly.ALIGN_RIGHT);
    this.appendValueInput('color_input')
      .setCheck(null)
      .appendField('燈光顏色')
      .setAlign(Blockly.ALIGN_RIGHT);
    this.setInputsInline(true);
    this.setOutput(true, null);
    this.setColour(255);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};


/* 
88""Yb 88   88 888888 888888  dP"Yb  88b 88 
88__dP 88   88   88     88   dP   Yb 88Yb88 
88""Yb Y8   8P   88     88   Yb   dP 88 Y88 
88oodP `YbodP'   88     88    YbodP  88  Y8 
*/

Blockly.Blocks['bit_button_event'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("當按鈕開關")
      .appendField(new Blockly.FieldDropdown([["A", "_bit_btnA_"], ["B", "_bit_btnB_"], ["A+B", "_bit_2btn_"]]), "var_")
      .appendField("被")
      .appendField(new Blockly.FieldDropdown([["按下", "pressed"], ["放開", "released"], ["長按", "longPress"]]), "event_");
    this.appendStatementInput("do_")
      .setCheck(null)
      .appendField("執行");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(200);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};


/*
8888b.  888888 888888 888888  dP""b8 888888 888888 8888b.  
 8I  Yb 88__     88   88__   dP   `"   88   88__    8I  Yb 
 8I  dY 88""     88   88""   Yb        88   88""    8I  dY 
8888Y"  888888   88   888888  YboodP   88   888888 8888Y"  
*/

Blockly.Blocks['bit_detected'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("偵測光線＆溫度 ( 重複無限次 )");
    this.appendStatementInput("do_")
      .setCheck(null)
      .appendField("執行");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(190);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['bit_photocell_val'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("亮度")
      .appendField(new Blockly.FieldDropdown([["左上", "_l_"], ["右上", "_r_"]]), "name_")
      .appendField("的數值 ( 流明 )");
    this.setOutput(true, null);
    this.setColour(195);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['bit_temp_val'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("溫度的數值 ( 度 C )");
    this.setOutput(true, null);
    this.setColour(195);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};


Blockly.Blocks['bit_detected_stop'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("停止偵測");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(190);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};


/*
88""Yb 88   88 8888P 8888P 888888 88""Yb 
88__dP 88   88   dP    dP  88__   88__dP 
88""Yb Y8   8P  dP    dP   88""   88"Yb  
88oodP `YbodP' d8888 d8888 888888 88  Yb 
*/

let notesAndTempos = [
  [' {"class":"bit-buzzer-icon icon-w", "frequency":"262", "title":"低音 C", "showTitle":"false", "keyboard":"true"}', 'C4'],
  ['{"class":"bit-buzzer-icon icon-b", "frequency":"277", "title":"低音 C#", "showTitle":"false", "keyboard":"true"}', 'CS4'],
  ['{"class":"bit-buzzer-icon icon-w", "frequency":"294", "title":"低音 D", "showTitle":"false", "keyboard":"true"}', 'D4'],
  ['{"class":"bit-buzzer-icon icon-b", "frequency":"311", "title":"低音 D#", "showTitle":"false", "keyboard":"true"}', 'DS4'],
  ['{"class":"bit-buzzer-icon icon-w", "frequency":"330", "title":"低音 E", "showTitle":"false", "keyboard":"true"}', 'E4'],
  ['{"class":"bit-buzzer-icon icon-w", "frequency":"349", "title":"低音 F", "showTitle":"false", "keyboard":"true"}', 'F4'],
  ['{"class":"bit-buzzer-icon icon-b", "frequency":"370", "title":"低音 F#", "showTitle":"false", "keyboard":"true"}', 'FS4'],
  ['{"class":"bit-buzzer-icon icon-w", "frequency":"392", "title":"低音 G", "showTitle":"false", "keyboard":"true"}', 'G4'],
  ['{"class":"bit-buzzer-icon icon-b", "frequency":"415", "title":"低音 G#", "showTitle":"false", "keyboard":"true"}', 'GS4'],
  ['{"class":"bit-buzzer-icon icon-w", "frequency":"440", "title":"低音 A", "showTitle":"false", "keyboard":"true"}', 'A4'],
  ['{"class":"bit-buzzer-icon icon-b", "frequency":"466", "title":"低音 A#", "showTitle":"false", "keyboard":"true"}', 'AS4'],
  ['{"class":"bit-buzzer-icon icon-w", "frequency":"494", "title":"低音 B", "showTitle":"false", "keyboard":"true"} ', 'B4'],
  [' {"class":"bit-buzzer-icon icon-w", "frequency":"523", "title":"中音 C", "showTitle":"false", "keyboard":"true"}', 'C5'],
  ['{"class":"bit-buzzer-icon icon-b", "frequency":"554", "title":"中音 C#", "showTitle":"false", "keyboard":"true"}', 'CS5'],
  ['{"class":"bit-buzzer-icon icon-w", "frequency":"587", "title":"中音 D", "showTitle":"false", "keyboard":"true"}', 'D5'],
  ['{"class":"bit-buzzer-icon icon-b", "frequency":"622", "title":"中音 D#", "showTitle":"false", "keyboard":"true"}', 'DS5'],
  ['{"class":"bit-buzzer-icon icon-w", "frequency":"659", "title":"中音 E", "showTitle":"false", "keyboard":"true"}', 'E5'],
  ['{"class":"bit-buzzer-icon icon-w", "frequency":"698", "title":"中音 F", "showTitle":"false", "keyboard":"true"}', 'F5'],
  ['{"class":"bit-buzzer-icon icon-b", "frequency":"740", "title":"中音 F#", "showTitle":"false", "keyboard":"true"}', 'FS5'],
  ['{"class":"bit-buzzer-icon icon-w", "frequency":"784", "title":"中音 G", "showTitle":"false", "keyboard":"true"}', 'G5'],
  ['{"class":"bit-buzzer-icon icon-b", "frequency":"831", "title":"中音 G#", "showTitle":"false", "keyboard":"true"}', 'GS5'],
  ['{"class":"bit-buzzer-icon icon-w", "frequency":"880", "title":"中音 A", "showTitle":"false", "keyboard":"true"}', 'A5'],
  ['{"class":"bit-buzzer-icon icon-b", "frequency":"932", "title":"中音 A#", "showTitle":"false", "keyboard":"true"}', 'AS5'],
  ['{"class":"bit-buzzer-icon icon-w", "frequency":"988", "title":"中音 B", "showTitle":"false", "keyboard":"true"} ', 'B5'],
  [' {"class":"bit-buzzer-icon icon-w", "frequency":"1047", "title":"高音 C", "showTitle":"false", "keyboard":"true"}', 'C6'],
  ['{"class":"bit-buzzer-icon icon-b", "frequency":"1109", "title":"高音 C#", "showTitle":"false", "keyboard":"true"}', 'CS6'],
  ['{"class":"bit-buzzer-icon icon-w", "frequency":"1175", "title":"高音 D", "showTitle":"false", "keyboard":"true"}', 'D6'],
  ['{"class":"bit-buzzer-icon icon-b", "frequency":"1245", "title":"高音 D#", "showTitle":"false", "keyboard":"true"}', 'DS6'],
  ['{"class":"bit-buzzer-icon icon-w", "frequency":"1319", "title":"高音 E", "showTitle":"false", "keyboard":"true"}', 'E6'],
  ['{"class":"bit-buzzer-icon icon-w", "frequency":"1397", "title":"高音 F", "showTitle":"false", "keyboard":"true"}', 'F6'],
  ['{"class":"bit-buzzer-icon icon-b", "frequency":"1480", "title":"高音 F#", "showTitle":"false", "keyboard":"true"}', 'FS6'],
  ['{"class":"bit-buzzer-icon icon-w", "frequency":"1568", "title":"高音 G", "showTitle":"false", "keyboard":"true"}', 'G6'],
  ['{"class":"bit-buzzer-icon icon-b", "frequency":"1661", "title":"高音 G#", "showTitle":"false", "keyboard":"true"}', 'GS6'],
  ['{"class":"bit-buzzer-icon icon-w", "frequency":"1760", "title":"高音 A", "showTitle":"false", "keyboard":"true"}', 'A6'],
  ['{"class":"bit-buzzer-icon icon-b", "frequency":"1865", "title":"高音 A#", "showTitle":"false", "keyboard":"true"}', 'AS6'],
  ['{"class":"bit-buzzer-icon icon-w", "frequency":"1976", "title":"高音 B", "showTitle":"false", "keyboard":"true"} ', 'B6']
];

Blockly.Blocks['buzzer_play_plus'] = {
  init: function () {
    this.appendValueInput("tone_")
      .setCheck("buzzer_tone")
      .setAlign(Blockly.ALIGN_RIGHT)
      .appendField("演奏 音階");
    this.appendValueInput("tempos_")
      .setCheck("buzzer_tempo")
      .setAlign(Blockly.ALIGN_RIGHT)
      .appendField("持續");
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(180);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['buzzer_tone'] = {
  init: function () {
    this.appendDummyInput()
      .appendField(new Blockly.FieldDropdown(notesAndTempos), 'tone_');
    this.setInputsInline(true);
    this.setOutput(true, "buzzer_tone");
    this.setColour(180);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['buzzer_tempo'] = {
  init: function () {
    this.appendDummyInput()
      .appendField(new Blockly.FieldDropdown([
        ['2', '1'],
        ['1', '2'],
        ['1/2', '4'],
        ['1/4', '6'],
        ['1/8', '8'],
        ['1/16', '10']
      ]), 'tempos_')
      .appendField('拍')
    this.setInputsInline(true);
    this.setOutput(true, "buzzer_tempo");
    this.setColour(180);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['buzzer_play_plus_mute_tone'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("休止符");
    this.setOutput(true, "buzzer_tone");
    this.setColour(180);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['buzzer_play_plus_mute'] = {
  init: function () {
    this.appendValueInput("tempos_")
      .setCheck("buzzer_tempo")
      .setAlign(Blockly.ALIGN_RIGHT)
      .appendField("演奏 休息");
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(180);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

//新版積木，合併 play 和音符節奏
Blockly.Blocks['buzzer_play'] = {
  init: function () {
    this.appendDummyInput()
      .appendField('演奏 音階')
      .appendField(new Blockly.FieldDropdown(notesAndTempos), 'tone_')
      .appendField('持續')
      .appendField(new Blockly.FieldDropdown([
        ['2', '1'],
        ['1', '2'],
        ['1/2', '4'],
        ['1/4', '6'],
        ['1/8', '8'],
        ['1/16', '10']
      ]), 'tempos_')
      .appendField('拍');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip('');
    this.setHelpUrl('');
    this.setColour(180);
  }
};

//新版積木，合併 play 和音符節奏
Blockly.Blocks['buzzer_play_music'] = {
  init: function () {
    this.appendDummyInput()
      .appendField('演奏 音樂')
      .appendField(new Blockly.FieldDropdown([
        ['超級瑪琍', 'm1'],
        ['超級瑪琍和弦', 'm4'],
        ['真善美', 'm2'],
        ['哥哥爸爸真偉大', 'm3'],
        ['叮叮噹', 'm5']
      ]), 'music_');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip('');
    this.setHelpUrl("");
    this.setColour(180);
  }
};

//新版積木，合併 play 和音符節奏
Blockly.Blocks['buzzer_play_mute'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("演奏 休息")
      .appendField(new Blockly.FieldDropdown([
        ['2', '1'],
        ['1', '2'],
        ['1/2', '4'],
        ['1/4', '6'],
        ['1/8', '8'],
        ['1/16', '10']
      ]), 'tempos_')
      .appendField('拍');
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(180);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

//新版積木，合併 play 和音符節奏
Blockly.Blocks['buzzer_play_event'] = {
  init: function () {
    this.appendDummyInput()
      .appendField(new Blockly.FieldDropdown([
        ['停止', '.stop()'],
        ['暫停', '.pause()'],
        ['繼續', '.play()']
      ]), 'event_')
      .appendField('演奏');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip('');
    this.setHelpUrl("");
    this.setColour(180);
  }
};


Blockly.Blocks['buzzer_mute'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("休止符")
      .appendField(new Blockly.FieldDropdown([
        ['2', '1'],
        ['1', '2'],
        ['1/2', '4'],
        ['1/4', '6'],
        ['1/8', '8'],
        ['1/16', '10']
      ]), 'tempos_')
      .appendField('拍');
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(185);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['buzzer_notes_tempos'] = {
  init: function () {
    this.appendDummyInput()
      .appendField('音符')
      .appendField(new Blockly.FieldDropdown(notesAndTempos), 'tone_')
      .appendField('持續')
      .appendField(new Blockly.FieldDropdown([
        ['2', '1'],
        ['1', '2'],
        ['1/2', '4'],
        ['1/4', '6'],
        ['1/8', '8'],
        ['1/16', '10']
      ]), 'tempos_')
      .appendField('拍');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip('');
    this.setHelpUrl('');
    this.setColour(185);
  }
};

Blockly.Blocks['buzzer_music_play'] = {
  init: function () {
    this.appendStatementInput('music_')
      .setCheck(null)
      .appendField('開始演奏');
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setTooltip('');
    this.setHelpUrl("");
    this.setColour(180);
  }
};

Blockly.Blocks['buzzer_event'] = {
  init: function () {
    this.appendDummyInput()
      .appendField(new Blockly.FieldDropdown([
        ['停止', '.stop()'],
        ['暫停', '.pause()'],
        ['繼續', '.play()']
      ]), 'event_')
      .appendField('演奏');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip('');
    this.setHelpUrl("");
    this.setColour(180);
  }
};

Blockly.Blocks['buzzer_state'] = {
  init: function () {
    this.appendDummyInput()
      .appendField('判斷演奏')
      .appendField(new Blockly.FieldDropdown([
        ['已經停止', 'stopped'],
        ['暫停中', 'paused'],
        ['進行中', 'playing']
      ]), 'state_');
    this.setOutput(true);
    this.setTooltip('');
    this.setHelpUrl("");
    this.setColour(185);
  }
};

Blockly.Blocks['buzzer_load_music'] = {
  init: function () {
    this.appendDummyInput()
      .appendField('音樂')
      .appendField(new Blockly.FieldDropdown([
        ['超級瑪琍', 'm1'],
        ['超級瑪琍和弦', 'm4'],
        ['真善美', 'm2'],
        ['哥哥爸爸真偉大', 'm3'],
        ['叮叮噹', 'm5']
      ]), 'music_');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip('');
    this.setHelpUrl("");
    this.setColour(185);
  }
};

/*
8b    d8 88""Yb 88   88 dP""Yb oP"Yb. 888888  dP"Yb  
88b  d88 88__dP 88   88 Ybood8 "' dP' 88oo." dP   Yb 
88YbdP88 88"""  Y8   8P   .8P'   dP'     `8b Yb   dP 
88 YY 88 88     `YbodP'  .dP'  .d8888 8888P'  YbodP  
*/

Blockly.Blocks['mpu9250_detected'] = {
  init: function () {
    this.appendDummyInput()
      .appendField('九軸體感偵測 ( 重複無限次 )');
    this.appendStatementInput("do_")
      .appendField('執行')
      .appendField(Blockly.Msg.WEBDUINO_MPU9250_DO);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour(130);
    this.setTooltip("");
    this.setHelpUrl("");
  },
  onchange: function () {
    if (this.getFieldValue('type_') === 'webduino.module.MPU9250Event.MAGNETOMETER_MESSAGE') {
      this.setFieldValue('webduino.module.MPU9250Event.ACCELEROMETER_MESSAGE', 'type_');
    }
  }
};

Blockly.Blocks['mpu9250_val'] = {
  init: function () {
    function getDropDownValue() {
      return [
        ['roll ( 前後翻轉 ↕ )', 'angVals[0]'],
        ['pitch ( 左右翻轉 ↔ )', 'angVals[1]'],
        ['yaw ( 水平旋轉 ↻ )', 'angVals[2]'],
        ['方位角 ( 電子羅盤 ➹ )', 'aziVals[0]'],
        ['x ( 加速度計 )', 'accVals[0]'],
        ['y ( 加速度計 )', 'accVals[1]'],
        ['z ( 加速度計 )', 'accVals[2]'],
        ['x ( 陀螺儀 )', 'gyrVals[0]'],
        ['y ( 陀螺儀 )', 'gyrVals[1]'],
        ['z ( 陀螺儀 )', 'gyrVals[2]'],
        ['x ( 磁力計 )', 'magVals[0]'],
        ['y ( 磁力計 )', 'magVals[1]'],
        ['z ( 磁力計 )', 'magVals[2]']
      ];
    }
    this.appendDummyInput()
      .appendField(new Blockly.FieldDropdown(getDropDownValue), "val_")
      .appendField('的數值');
    this.setOutput(true, null);
    this.setColour(135);
    this.setTooltip("");
    this.setHelpUrl("");
  },
  onchange: function () {
    var val_ = this.getFieldValue('val_');
    switch (val_) {
      case '_x':
        this.setFieldValue('accVals[0]', 'val_');
        break;
      case '_y':
        this.setFieldValue('accVals[1]', 'val_');
        break;
      case '_z':
        this.setFieldValue('accVals[2]', 'val_');
        break;
      default:
        break;
    }
  }
};

Blockly.Blocks['mpu9250_stop'] = {
  init: function () {
    this.appendDummyInput()
      .appendField('停止偵測');
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour(130);
    this.setTooltip('');
    this.setHelpUrl('');
  },
  onchange: function () {
    if (this.getFieldValue('type_') === 'webduino.module.MPU9250Event.MAGNETOMETER_MESSAGE') {
      this.setFieldValue('webduino.module.MPU9250Event.ACCELEROMETER_MESSAGE', 'type_');
    }
  }
};

let mpu9250_type = [
  [' {"class":"bit-mpu9250-icon icon-01", "title":"晃動", "showTitle":"false"}', "shake"],
  ['{"class":"bit-mpu9250-icon icon-02", "title":"正面朝上", "showTitle":"false"}', "face_front"],
  ['{"class":"bit-mpu9250-icon icon-03", "title":"向後翻轉", "showTitle":"false"}', "row_back"],
  ['{"class":"bit-mpu9250-icon icon-04", "title":"向右翻轉", "showTitle":"false"}', "pitch_right"],
  ['{"class":"bit-mpu9250-icon icon-05", "title":"向右旋轉", "showTitle":"false"}', "forward_pitch_right"],
  ['{"class":"bit-mpu9250-icon icon-06", "title":"靜止不動", "showTitle":"false"}', "peace"],
  ['{"class":"bit-mpu9250-icon icon-07", "title":"背面朝上", "showTitle":"false"}', "face_back"],
  ['{"class":"bit-mpu9250-icon icon-08", "title":"向前翻轉", "showTitle":"false"}', "row_forward"],
  ['{"class":"bit-mpu9250-icon icon-09", "title":"向左翻轉", "showTitle":"false"}', "pitch_left"],
  ['{"class":"bit-mpu9250-icon icon-10", "title":"向左旋轉", "showTitle":"false"}', "forward_pitch_left"],
  ['{"class":"bit-mpu9250-icon icon-11", "title":"指向北方", "showTitle":"false"}', "face_north"],
  ['{"class":"bit-mpu9250-icon icon-12", "title":"指向西方", "showTitle":"false"}', "face_west"],
  ['{"class":"bit-mpu9250-icon icon-13", "title":"指向南方", "showTitle":"false"}', "face_south"],
  ['{"class":"bit-mpu9250-icon icon-14", "title":"指向東方", "showTitle":"false"} ', "face_east"]
];

Blockly.Blocks['mpu9250_detected_type'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("如果開發板")
      .appendField(new Blockly.FieldDropdown(mpu9250_type), "type_");
    this.appendStatementInput("do_")
      .setCheck(null)
      .appendField("執行");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(130);
    this.setTooltip("");
    this.setHelpUrl("");
    this.setCommentText("獨立使用，不需放在迴圈積木內");
  }
};



/*
8888b.  888888 8b    d8  dP"Yb  
 8I  Yb 88__   88b  d88 dP   Yb 
 8I  dY 88""   88YbdP88 Yb   dP 
8888Y"  888888 88 YY 88  YbodP  
*/

var monsterList = [
  ['{"src":"media/demo-edu-a1-s.png", "width":"30", "height":"42", "title":"綠色怪獸", "showTitle":"true"}', 'demoMonster01'],
  ['{"src":"media/demo-edu-a2-s.png", "width":"30", "height":"42", "title":"紅色怪獸", "showTitle":"true"}', 'demoMonster02'],
  ['{"src":"media/demo-edu-a3-s.png", "width":"30", "height":"42", "title":"黃色怪獸", "showTitle":"true"}', 'demoMonster03'],
  ['{"src":"media/demo-edu-a4-s.png", "width":"30", "height":"42", "title":"藍色怪獸", "showTitle":"true"} ', 'demoMonster04']
];
var monsterList_all = [
  ['{"src":"media/demo-edu-a1-s.png", "width":"30", "height":"42", "title":"綠色怪獸", "showTitle":"true"}', 'demoMonster01'],
  ['{"src":"media/demo-edu-a2-s.png", "width":"30", "height":"42", "title":"紅色怪獸", "showTitle":"true"}', 'demoMonster02'],
  ['{"src":"media/demo-edu-a3-s.png", "width":"30", "height":"42", "title":"黃色怪獸", "showTitle":"true"}', 'demoMonster03'],
  ['{"src":"media/demo-edu-a4-s.png", "width":"30", "height":"42", "title":"藍色怪獸", "showTitle":"true"}', 'demoMonster04'],
  ['{"src":"media/demo-edu-all-s.png", "width":"30", "height":"42", "title":"所有怪獸", "showTitle":"true"} ', 'all']
];

Blockly.Blocks['demo_monster_click'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("當滑鼠點擊")
      .appendField(new Blockly.FieldDropdown(monsterList), "name_");
    this.appendStatementInput("do_")
      .setCheck(null)
      .appendField("執行");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['demo_monster_hover'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("當滑鼠接觸")
      .appendField(new Blockly.FieldDropdown(monsterList), "name_");
    this.appendStatementInput("do1_")
      .setCheck(null)
      .appendField("碰到時，執行");
    this.appendStatementInput("do2_")
      .setCheck(null)
      .appendField("離開時，執行");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['demo_monster_emotion'] = {
  init: function () {
    this.appendDummyInput()
      .appendField(new Blockly.FieldDropdown(monsterList_all), "name_")
      .appendField("的情緒為")
      .appendField(new Blockly.FieldDropdown([["正常", "0"], ["開心", "1"], ["驚訝", "2"], ["難過", "3"], ["生氣", "4"], ["隨機", "random"]]), "type_");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};
Blockly.Blocks['demo_monster_zindex'] = {
  init: function () {
    this.appendDummyInput()
      .appendField(new Blockly.FieldDropdown(monsterList), "name_")
      .appendField("的階層移到")
      .appendField(new Blockly.FieldDropdown([["最上層", "1"], ["最下層", "2"]]), "level_");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['demo_monster_talk'] = {
  init: function () {
    this.appendValueInput("val_")
      .setCheck(null)
      .appendField(new Blockly.FieldDropdown(monsterList_all), "name_")
      .appendField("說");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['demo_monster_dont_talk'] = {
  init: function () {
    this.appendDummyInput()
      .appendField(new Blockly.FieldDropdown(monsterList_all), "name_")
      .appendField("不說話");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['demo_monster_show_image'] = {
  init: function () {
    this.appendValueInput("img_")
      .setCheck(null)
      .appendField(new Blockly.FieldDropdown(monsterList_all), "name_")
      .appendField("展示圖片");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['demo_monster_rotate'] = {
  init: function () {
    this.appendValueInput("val_")
      .setCheck(null)
      .appendField(new Blockly.FieldDropdown(monsterList_all), "name_")
      .appendField(new Blockly.FieldDropdown([["左轉", "left"], ["右轉", "right"]]), "rotate_");
    this.appendDummyInput()
      .appendField("度");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};


Blockly.Blocks['demo_monster_faceto'] = {
  init: function () {
    this.appendValueInput("val_")
      .setCheck(null)
      .appendField(new Blockly.FieldDropdown(monsterList_all), "name_")
      .appendField("面朝");
    this.appendDummyInput()
      .appendField("度");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['demo_monster_face_mouse'] = {
  init: function () {
    this.appendDummyInput()
      .appendField(new Blockly.FieldDropdown(monsterList_all), "name_")
      .appendField(new Blockly.FieldDropdown([["自動", "auto"], ["停止", "stop"]]), "type_")
      .appendField("面朝滑鼠方向");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['demo_monster_sizeto'] = {
  init: function () {
    this.appendValueInput("val_")
      .setCheck("Number")
      .appendField(new Blockly.FieldDropdown(monsterList_all), "name_")
      .appendField("的尺寸設定為");
    this.appendDummyInput()
      .appendField("%");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['demo_monster_size'] = {
  init: function () {
    this.appendValueInput("val_")
      .setCheck("Number")
      .appendField(new Blockly.FieldDropdown(monsterList_all), "name_")
      .appendField("的尺寸")
      .appendField(new Blockly.FieldDropdown([["變大", "big"], ["變小", "small"]]), "type_");
    this.appendDummyInput()
      .appendField("點");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['demo_monster_display'] = {
  init: function () {
    this.appendDummyInput()
      .appendField(new Blockly.FieldDropdown(monsterList_all), "name_")
      .appendField("在舞台畫面中")
      .appendField(new Blockly.FieldDropdown([["隱藏", "hide"], ["顯示", "show"]]), "type_");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['demo_monster_state'] = {
  init: function () {
    this.appendDummyInput()
      .appendField(new Blockly.FieldDropdown(monsterList), "name_")
      .appendField("的")
      .appendField(new Blockly.FieldDropdown([["x 座標", "x"], ["y 座標", "y"], ["旋轉角度", "deg"]]), "state_");
    this.setOutput(true, null);
    this.setColour(105);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['demo_monster_stage'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("當")
      .appendField(new Blockly.FieldDropdown(monsterList), "name_")
      .appendField("碰到舞台畫面的")
      .appendField(new Blockly.FieldDropdown([["四個邊緣", "edge"], ["上面 或 下面", "topOrBottom"], ["左側 或 右側", "letOrRight"], ["上面", "top"], ["下面", "bottom"], ["左側", "left"], ["右側", "right"]]), "stage_");
    this.appendStatementInput("do_")
      .setCheck(null)
      .appendField("執行");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['demo_monster_stage_rebound'] = {
  init: function () {
    this.appendDummyInput()
      .appendField(new Blockly.FieldDropdown(monsterList_all), "name_")
      .appendField("碰到舞台邊緣就反彈");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['demo_monster_reset'] = {
  init: function () {
    this.appendDummyInput()
      .appendField(new Blockly.FieldDropdown(monsterList_all), "name_")
      .appendField("回到原始狀態");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['demo_monster_move'] = {
  init: function () {
    this.appendValueInput("val_")
      .setCheck(null)
      .appendField(new Blockly.FieldDropdown(monsterList_all), "name_")
      .appendField("往")
      .appendField(new Blockly.FieldDropdown([["上", "top"], ["下", "bottom"], ["左", "left"], ["右", "right"], ["隨機位置", "random"], ["滑鼠位置", "mouse"]]), "move_")
      .appendField("移動");
    this.appendDummyInput()
      .appendField("點");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};


Blockly.Blocks['demo_monster_moveto'] = {
  init: function () {
    this.appendValueInput("x_")
      .setCheck(null)
      .appendField(new Blockly.FieldDropdown(monsterList_all), "name_")
      .appendField("定位到 x")
      .setAlign(Blockly.ALIGN_RIGHT);
    this.appendValueInput("y_")
      .setCheck(null)
      .appendField("y")
      .setAlign(Blockly.ALIGN_RIGHT);
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['demo_monster_collision'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("當")
      .appendField(new Blockly.FieldDropdown(monsterList), "m1_")
      .appendField("碰到")
      .appendField(new Blockly.FieldDropdown(monsterList), "m2_");
    this.appendStatementInput("do_")
      .setCheck(null)
      .appendField("執行");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['demo_monster_background_color'] = {
  init: function () {
    this.appendValueInput("color_")
      .setCheck(null)
      .appendField("更換怪獸舞台背景顏色為");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['demo_monster_background_image'] = {
  init: function () {
    this.appendValueInput("image_")
      .setCheck(null)
      .appendField("更換怪獸舞台背景圖片為");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['demo_monster_stage_max'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("設定怪獸舞台為全螢幕");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(100);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['demo_monster_stage_size'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("怪獸舞台的")
      .appendField(new Blockly.FieldDropdown([["寬度", "width"], ["高度", "height"]]), "type_");
    this.setOutput(true, null);
    this.setColour(105);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

let sound_01 = [
  ["貓", "cat-01"],
  ["狗", "dog-01"],
  ["獅子", "lion-01"],
  ["山羊", "goat-01"],
  ["大象", "elephant-01"],
  ["公雞", "chicken-01"],
  ["小雞", "chicken-02"],
  ["鴨子", "duck-01"],
  ["烏鴉", "crow-01"],
  ["猴子", "monkey-01"],
  ["青蛙", "frog-01"],
  ["老鼠", "mouse-01"],
  ["豬", "pig-01"],
  ["隨機", "random"]
];

Blockly.Blocks['sound_01'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("播放動物音效")
      .appendField(new Blockly.FieldDropdown(sound_01), "sound_");
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(40);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

let sound_02 = [
  ["答對了", "sound-01"],
  ["清脆的咚", "sound-02"],
  ["清脆的嗶", "sound-03"],
  ["電子的嘟聲", "sound-04"],
  ["擊打聲", "sound-05"],
  ["鏘的一聲", "sound-06"],
  ["雷射光", "sound-07"],
  ["門鈴的叮咚", "sound-08"],
  ["骰子聲", "sound-09"],
  ["水中泡泡", "sound-10"],
  ["汽車喇叭", "sound-11"],
  ["吃金幣", "coin-01"],
  ["彈跳", "jump-01"],
  ["陣亡了", "death-01"],
  ["腳踏車鈴鐺", "bell-01"],
  ["隨機", "random"]
];

Blockly.Blocks['sound_02'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("播放特殊音效")
      .appendField(new Blockly.FieldDropdown(sound_02), "sound_");
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(40);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};

let sound_03 = [
  ["打噴嚏", "sneeze-01"],
  ["笑聲", "laugth-01"],
  ["咳嗽", "cough-01"],
  ["親吻", "kiss-01"],
  ["鼓掌", "applaud-01"],
  ["哭聲", "cry-01"],
  ["打嗝", "snoring-01"],
  ["放屁", "fart-01"],
  ["吹口哨", "whistle-01"],
  ["鼾聲", "snore-01"],
  ["嘆氣", "sigh-01"],
  ["嚇一跳", "sigh-02"],
  ["隨機", "random"]
];

Blockly.Blocks['sound_03'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("播放人聲音效")
      .appendField(new Blockly.FieldDropdown(sound_03), "sound_");
    this.setInputsInline(true);
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(40);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};


/*
.dP"Y8 88""Yb 888888 888888  dP""b8 88  88 
`Ybo." 88__dP 88__   88__   dP   `" 88  88 
o.`Y8b 88"""  88""   88""   Yb      888888 
8bodP' 88     888888 888888  YboodP 88  88 
*/

Blockly.Blocks['speech_recognition'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("語音辨識，語言")
      .appendField(new Blockly.FieldDropdown([["中文", "cmn-Hant-TW"], ["英文", "en-US"]]), "lang_")
      .appendField(" ( 僅支援 Chrome、Android )");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(40);
    this.setTooltip("");
    this.setHelpUrl("");
    this.setCommentText("語音辨識之後，才會繼續執行下方程式");
  }
};

Blockly.Blocks['speech_recognition_value'] = {
  init: function () {
    this.appendDummyInput()
      .appendField("語音辨識的文字");
    this.setOutput(true, null);
    this.setColour(45);
    this.setTooltip("");
    this.setHelpUrl("");
  }
};


