const appInfo = require('./package.json');
const OTA_BASE_URL = 'https://sevenbai-wb.github.io/WebBitOTA/';
const request = require('request');
const fs = require('fs');
const admzip = require('adm-zip');
let d = new Date();
let r = '?' + d.getTime();
let currentVs = appInfo.version ? appInfo.version.split('.') : ["1", "2", "0"];
OTA_BASE_URL += (currentVs[0] + '.' + currentVs[1] + '/');
request(OTA_BASE_URL + 'package.json' + r, (err, res, data) => {
    try {
        let otaPkgInfo = JSON.parse(data);
        let currentV = currentVs[2];
        if (!otaPkgInfo.version) otaPkgInfo.version = "1.2.0";
        let otaV = (otaPkgInfo.version.split('.'))[2];
        if (!err && otaV > currentV) {
            // backup package.json
            fs.copyFileSync(__dirname + '/package.json', __dirname + '/package.json' + appInfo.version);

            // unload package.json
            var pkgModule = require.resolve('./package.json');
            delete require.cache[pkgModule];

            fs.writeFileSync(__dirname + '/package.json', data);
            request(OTA_BASE_URL + 'ota.zip' + r, (err, res, data) => {
                let zipfile = __dirname + '/' + otaPkgInfo.version + '_ota.zip';
                fs.writeFileSync(zipfile, data);
                let zip = new admzip(zipfile);
                zip.extractAllTo('./', /*overwrite*/true);
                require('./launcher');  // restart from new launcher after OTA
            });
        } else {
            require('./main');
        }
    } catch (error) {
        require('./main');
    }
});